import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

import Global from '../assets/global/Styles';

class CardContent extends React.Component {
  render() {
    const { children } = this.props;    
    return (  
      <View style={styles.cardContent}>
        {children}
      </View>  
    );
  }
}

const styles = StyleSheet.create({  
    cardContent: {
      width: '100%',
      backgroundColor: Global.WHITE_COLOR,
      // borderLeftWidth: 1,
      // borderRightWidth: 1,
      // borderBottomWidth: 1,
      // borderColor: Global.BORDER_COLOR,
      padding: 10,
      shadowColor: Global.BLACK_COLOR,
      shadowOffset: { width: 0, height: 5 },
      shadowOpacity: 0.5,
      shadowRadius: 5,
      elevation: 2,

    },
});

export default CardContent;
