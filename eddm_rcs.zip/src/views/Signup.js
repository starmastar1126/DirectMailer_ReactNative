/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View, Alert, TouchableOpacity, TextInput} from 'react-native';
// import { Div } from 'react-native-div';

const instructions = Platform.select({
  ios: 'Press Cmd+R to reload,\n' + 'Cmd+D or shake for dev menu',
  android:
    'Double tap R on your keyboard to reload,\n' +
    'Shake or press menu button for dev menu',
});

export default class Signup extends Component {

    static navigationOptions = {
        header: null
    };

    onSignin() {
        Alert.alert('on Press!');
    }

    onSignin() {
        Alert.alert('on Closed!');
    }

    render() {
        return (
            <View style={styles.container}>
                <View style={styles.container_inner}>
                    <View style={styles.container_signup_div}>
                        <View style={styles.signup_header_div}>
                            <TouchableOpacity style={styles.closeButton} onPress={this.onClose}>
                                <View>
                                    <Text style={{fontSize: 25, color: '#EEEEEE'}}>×</Text>
                                </View>
                            </TouchableOpacity>
                        </View>
                        <View style={styles.signup_content_div}>
                            <Text style={{fontSize: 35, color: '#7F9096'}}>EDDM Register</Text>
                            <View style={{width: '100%', paddingLeft: 20, paddingRight: 20, marginTop: 50}}>
                                <TextInput
                                        style={{width: '100%', backgroundColor: '#FFFFFF', fontSize: 25}}
                                        placeholder="Email address"
                                />
                            </View>
                            <View style={{width: '100%', paddingLeft: 20, paddingRight: 20, marginTop: 30}}>
                                <TextInput
                                        style={{width: '100%', backgroundColor: '#FFFFFF', fontSize: 25}}
                                        placeholder="Choose a password"
                                        secureTextEntry={true}
                                />
                            </View>
                            <View style={{width: '100%', paddingLeft: 20, paddingRight: 20, marginTop: 30}}>
                                <TextInput
                                        style={{width: '100%', backgroundColor: '#FFFFFF', fontSize: 25}}
                                        placeholder="Confirm your password"
                                        secureTextEntry={true}
                                />
                            </View>
                            <View style={{width: '100%', marginTop: 30, alignItems: 'center'}}>
                                <TouchableOpacity style={styles.activeButton} onPress={this.onSignin}>
                                    <View>
                                        <Text style={styles.buttonText}>REGISTER</Text>
                                    </View>
                                </TouchableOpacity>
                            </View>
                            <View style={{width: '100%', marginTop: 25, alignItems: 'center'}}>
                                <TouchableOpacity style={styles.inactiveButton} onPress={this.onSignin}>
                                    <View>
                                        <Text style={{fontSize: 25, color: '#7F9096'}}>Login</Text>
                                    </View>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#EEEEEE',
    paddingTop: 80,
    paddingLeft: 60,
    paddingRight: 60,
    paddingBottom: 80,
  },
  container_inner: {
    borderRadius: 5,
    backgroundColor: '#FFFFFF',
    width: '100%',
    height: '100%',
    paddingTop: 150,
    paddingLeft: 10,
    paddingRight: 10,
    paddingBottom: 150,
  },
  container_signup_div: {
    borderRadius: 5,
    backgroundColor: '#CFD8DC',
    width: '100%',
    height: '100%',
    padding: 10,
  },
  signup_header_div: {
    width: '100%',
    marginTop: 10,
    flexDirection: 'column',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: 30,
  },
  signup_content_div: {
    width: '100%',
    height: '100%',
    marginTop: 30,
    alignItems: 'center',
    padding: 5,
  },
  closeButton: {
    width: 36,
    height: 36,
    backgroundColor: '#7B8D93',
    borderRadius: 18,
    alignItems: 'center',
  },
  activeButton: {
    width: 180,
    height: 50,
    backgroundColor: '#7B8D93',
    borderRadius: 5,
    padding: 10,
    alignItems: 'center',
  },
  inactiveButton: {
    width: 180,
    height: 30,
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 20,
    color: '#EEEEEE',
    fontWeight: 'bold',
  },
});
