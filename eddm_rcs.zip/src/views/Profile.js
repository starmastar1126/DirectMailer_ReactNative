/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View, Alert, TouchableOpacity, TextInput} from 'react-native';
// import { Div } from 'react-native-div';

const instructions = Platform.select({
  ios: 'Press Cmd+R to reload,\n' + 'Cmd+D or shake for dev menu',
  android:
    'Double tap R on your keyboard to reload,\n' +
    'Shake or press menu button for dev menu',
});

export default class Profile extends Component {

    static navigationOptions = {
        header: (
            <View
                style={{
                    height: 65,
                    backgroundColor: '#7B8D93',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                }}>
                <View style={{width: 70}}>
                    <TouchableOpacity onPress={() => alert('Right Menu Clicked')}>
                        <Text
                            style={{
                                color: 'white',
                                fontSize: 20,
                            }}>
                            Back
                        </Text>
                    </TouchableOpacity>
                </View>
                <Text
                    style={{
                    color: 'white',
                    textAlign: 'center',
                    fontSize: 25,
                    }}>
                    User Profile
                </Text>
                <View style={{width: 70}}></View>
            </View>
        ),
    };

    onSignin() {
        Alert.alert('on Press!');
    }

    onSave() {
        Alert.alert('on Save!');
    }

    render() {
        return (
            <View style={styles.container}>
                <View style={styles.img_circle_div}>
                    <Text style={styles.img_text}>avatar</Text>
                </View>
                <View style={{width: '100%', paddingLeft: 20, paddingRight: 20, marginTop: 30}}>
                    <TextInput
                            style={styles.input_text}
                            placeholder="First name"
                            // returnKeyLabel = {"next"}
                            // onChangeText={(text) => this.setState({text})}
                    />
                </View>
                <View style={{width: '100%', paddingLeft: 20, paddingRight: 20, marginTop: 30}}>
                    <TextInput
                            style={styles.input_text}
                            placeholder="Last name"
                            // returnKeyLabel = {"next"}
                            // onChangeText={(text) => this.setState({text})}
                    />
                </View>
                <View style={{width: '100%', paddingLeft: 20, paddingRight: 20, marginTop: 30}}>
                    <TextInput
                            style={styles.input_text}
                            placeholder="Address line1"
                            // returnKeyLabel = {"next"}
                            // onChangeText={(text) => this.setState({text})}
                    />
                </View>
                <View style={{width: '100%', paddingLeft: 20, paddingRight: 20, marginTop: 30}}>
                    <TextInput
                            style={styles.input_text}
                            placeholder="Address line2"
                            // returnKeyLabel = {"next"}
                            // onChangeText={(text) => this.setState({text})}
                    />
                </View>
                <View style={{width: '100%', paddingLeft: 20, paddingRight: 20, marginTop: 30}}>
                    <TextInput
                            style={styles.input_text}
                            placeholder="City"
                            // returnKeyLabel = {"next"}
                            // onChangeText={(text) => this.setState({text})}
                    />
                </View>
                <View style={{width: '100%', flexDirection: 'row', paddingLeft: 20, paddingRight: 20, marginTop: 30}}>
                    <View style={{flex: 1, paddingRight: 20}}>
                        <TextInput  style={[styles.input_text, styles.flex_start_input]} placeholder="State"
                                // returnKeyLabel = {"next"}
                                // onChangeText={(text) => this.setState({text})}
                        />
                    </View>
                    <View style={{flex: 1, paddingLeft: 20}}>
                        <TextInput style={[styles.input_text, styles.flex_end_input]} placeholder="ZIP code"
                                // returnKeyLabel = {"next"}
                                // onChangeText={(text) => this.setState({text})}
                        />
                    </View>
                </View>
                <View style={{width: '100%', paddingLeft: 20, paddingRight: 20, marginTop: 30}}>
                    <TextInput
                            style={styles.input_text}
                            placeholder="Phone number"
                            // returnKeyLabel = {"next"}
                            // onChangeText={(text) => this.setState({text})}
                    />
                </View>
                <View style={{width: '100%', marginTop: 50, alignItems: 'center'}}>
                    <TouchableOpacity style={styles.activeButton} onPress={this.onSave}>
                        <View>
                            <Text style={styles.buttonText}>SAVE</Text>
                        </View>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        width: '100%',
        height: '100%',
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#CFD8DC',
        paddingLeft: 50,
        paddingRight: 50
    },
    activeButton: {
        width: 180,
        height: 50,
        backgroundColor: '#7B8D93',
        borderRadius: 5,
        padding: 10,
        alignItems: 'center',
    },
    buttonText: {
        fontSize: 20,
        color: '#EEEEEE',
        fontWeight: 'bold',
    },
    img_circle_div: {
        width: 120,
        height: 120,
        backgroundColor: '#FFFFFF',
        // backgroundPosition: 'center',
        // backgroundSize: 'cover',
        borderRadius: 60,
        alignItems: 'center',
    },
    img_text: {
        width: '100%',
        height: '100%',
        textAlignVertical: 'center',
        textAlign: 'center',
        fontSize: 20
    },
    input_text: {
        width: '100%',
        backgroundColor: '#FFFFFF',
        borderRadius: 5,
        fontSize: 25
    },
    flex_start_input: {
        justifyContent: 'flex-start'
    },
    flex_end_input: {
        justifyContent: 'flex-end'
    }
});
