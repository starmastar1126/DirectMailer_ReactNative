/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View, Alert, TouchableOpacity, TextInput} from 'react-native';
// import { Div } from 'react-native-div';

const instructions = Platform.select({
  ios: 'Press Cmd+R to reload,\n' + 'Cmd+D or shake for dev menu',
  android:
    'Double tap R on your keyboard to reload,\n' +
    'Shake or press menu button for dev menu',
});

export default class Campaign extends Component {

    static navigationOptions = {
        header: null
    };

    onSignin() {
        Alert.alert('on Press!');
    }

    onSignin() {
        Alert.alert('on Closed!');
    }

    render() {
        return (
            <View style={styles.container}>
                <View style={styles.container_inner}>
                    <View style={styles.container_campaign_div}>
                        <View style={styles.campaign_header_div}>
                            <TouchableOpacity style={styles.closeButton} onPress={this.onClose}>
                                <View>
                                    <Text style={{fontSize: 25, color: '#EEEEEE'}}>×</Text>
                                </View>
                            </TouchableOpacity>
                        </View>
                        <View style={styles.campaign_content_div}>
                            <Text style={{fontSize: 35, color: '#7F9096', marginTop: 20}}>Email Verification</Text>
                            <Text style={{fontSize: 25, color: '#7F9096', marginTop: 25}}>Please confirmation your mail inbox</Text>
                            <Text style={{fontSize: 25, color: '#7F9096'}}>to verify your registration</Text>
                            <Text style={{fontSize: 35, color: '#7F9096', marginTop: 30}}>myemail@mail.com</Text>
                            <View style={{width: '100%', marginTop: 50, alignItems: 'center'}}>
                                <TouchableOpacity style={styles.activeButton} onPress={this.onSignin}>
                                    <View>
                                        <Text style={styles.buttonText}>RESEND</Text>
                                    </View>
                                </TouchableOpacity>
                            </View>
                            <View style={{width: '100%', marginTop: 35, alignItems: 'center'}}>
                                <TouchableOpacity style={styles.activeButton} onPress={this.onSignin}>
                                    <View>
                                        <Text style={styles.buttonText}>GO</Text>
                                    </View>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#EEEEEE',
    paddingTop: 80,
    paddingLeft: 60,
    paddingRight: 60,
    paddingBottom: 80,
  },
  container_inner: {
    borderRadius: 5,
    backgroundColor: '#FFFFFF',
    width: '100%',
    height: '100%',
    paddingTop: 100,
    paddingLeft: 10,
    paddingRight: 10,
    paddingBottom: 120,
  },
  container_campaign_div: {
    borderRadius: 5,
    backgroundColor: '#CFD8DC',
    width: '100%',
    height: '100%',
    padding: 10,
  },
  campaign_header_div: {
    width: '100%',
    flexDirection: 'column',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: 30,
    marginTop: 10,
  },
  campaign_content_div: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    padding: 5,
  },
  closeButton: {
    width: 36,
    height: 36,
    backgroundColor: '#7B8D93',
    borderRadius: 18,
    alignItems: 'center',
  },
  activeButton: {
    width: 180,
    height: 50,
    backgroundColor: '#7B8D93',
    borderRadius: 5,
    padding: 10,
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 20,
    color: '#EEEEEE',
    fontWeight: 'bold',
  },
});
