
import Signup from './src/views/Campaign';

import { createAppContainer, createStackNavigator } from 'react-navigation';
import { Dimensions } from 'react-native';

const deviceW = Dimensions.get('window').width;

const basePx = 375;

const MoonMinerNavigator = createStackNavigator({
    Signup: {screen: Signup},  
},
{
    initialRouteName: 'Signup'
});
const AppContainer = createAppContainer(MoonMinerNavigator);
export default AppContainer;