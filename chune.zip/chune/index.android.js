import { AppRegistry } from 'react-native';
import ChuneApp from './src';

AppRegistry.registerComponent('ChuneApp', () => ChuneApp);
