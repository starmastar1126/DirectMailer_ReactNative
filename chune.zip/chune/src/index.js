import RouteIniter from './routes/configs';
import ModelIniter from './model/initializer';
import gAppStates from './common/states';
import App from './app/setup';

RouteIniter;
ModelIniter;
gAppStates;

export default App;
