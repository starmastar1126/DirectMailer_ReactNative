export default {
  TUNE_STATE: 'tune/TUNE_STATE',
};
