export default {
  DATA_CHANGED: 'meteor/DATA_CHANGED',
};
