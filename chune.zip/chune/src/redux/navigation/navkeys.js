export default {
  app: 'root',
  clash: 'clash',
};
