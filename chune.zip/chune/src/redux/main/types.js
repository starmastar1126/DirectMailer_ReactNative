export default {
  LOGGED_IN: 'main/LOGGED_IN',
  JUDGE_FLAG: 'main/JUDGE_FLAG',
};
