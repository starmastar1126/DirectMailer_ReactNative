export default {
  TOGGLE: 'player/TOGGLE_PLAY',
  PLAY: 'player/PLAY',
  RESET: 'player/RESET',
  STATE: 'player/STATE',
};
