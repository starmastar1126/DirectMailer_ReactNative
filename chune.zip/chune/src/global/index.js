import * as g from './global';

export default g;
