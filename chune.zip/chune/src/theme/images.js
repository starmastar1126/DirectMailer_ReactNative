const images = {
  bg_splash: require('../../res/images/bg_splash.jpg'),
  ic_bottom_logo: require('../../res/images/ic_bottom_logo.png'),
};

export default images;
