import React, { Component } from 'react';
import { View, Image, Text } from 'react-native';
import { AnimateList } from '@components';
import { connect } from 'react-redux';
import styles from './Test-styles';

class Test extends Component {
  constructor(props) {
    super(props);
    this.cards = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  }

  _renderHeader = () => (
    <View style={styles.header} />
  )

  _renderRow = (card) => {
    const eventThumb = 'https://placeimg.com/640/480/any';
    const eventName = `Card Title ${card}`;

    return (
      <View style={styles.card_wrapper} >
        <View style={styles.card_content} >
          <Image source={{ uri: eventThumb }} resizeMode="cover" style={styles.img_card_thumb} />
          <View style={styles.view_card_title} >
            <Text style={styles.txt_card_title} >{eventName}</Text>
          </View>
        </View>
      </View>
    );
  }

  render() {
    return (
      <View style={styles.container} >
        <AnimateList
          style={styles.list}
          cards={this.cards}
          renderRow={this._renderRow}
          renderHeader={this._renderHeader}
        />
      </View>
    );
  }
}

const mapStateToProps = state => ({ // eslint-disable-line
});

const mapDispatchToProps = dispatch => ({
  dispatcher: state => dispatch(state),
});

export default connect(mapStateToProps, mapDispatchToProps)(Test);
