import Splash from './Splash';
// import Test from './Test';

export {
  Splash,
  // Test,
};
