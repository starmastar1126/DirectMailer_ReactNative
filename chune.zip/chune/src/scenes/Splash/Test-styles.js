import { StyleSheet } from 'react-native';
import { basestyles as bs, colors, sizes } from '@theme';

const space = 20;
const cardWidth = sizes.screen.width - space * 2;
const cardHeight = cardWidth * 9 / 16;
const borderRadius = 8;

export default StyleSheet.create({
  container: {
    ...bs.layout.match_parent,
    ...bs.align.center,
    backgroundColor: colors.background,
    paddingTop: 100,
  },
  list: {
    ...bs.layout.match_parent,
  },
  header: {
    ...bs.align.self.stretch,
    height: 100,
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 6,
    elevation: 3,
    marginBottom: space,
  },

  card_wrapper: {
    ...bs.align.center,
    width: cardWidth,
    borderRadius,
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 3,
    marginTop: space / 2,
    marginBottom: space / 2,
  },
  card_content: {
    ...bs.align.self.stretch,
    ...bs.align.center,
    overflow: 'hidden',
    borderRadius,
  },

  view_card_title: {
    ...bs.align.self.stretch,
    ...bs.align.center,
    padding: 8,
  },

  img_card_thumb: {
    width: cardWidth,
    height: cardHeight,
    // borderRadius,
  },

  txt_card_title: {
    ...bs.font.normal,
    fontSize: 16,
    color: 'black',
  },
});
