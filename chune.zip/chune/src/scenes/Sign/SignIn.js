import React, { Component } from 'react';
import { View, Text, TextInput } from 'react-native';
import { Button } from '@components/button';
import { ZCIcon, IOIcon } from '@components/icons';
import KeyboardScrollView from '@lib/KeyboardScrollView';
import Hyperlink from 'react-native-hyperlink';
import g from '@common/global';
import { connect } from 'react-redux';
import { handler, actions as reduxActions, bindActionCreators } from '@redux';
import { apis } from '@lib';
import { gAppStates } from '@common';
import bs from '@theme/basestyles';
import styles from './SignIn.styles';

const { navigation: navHandler } = handler;

class SignIn extends Component {

  state = {
    email: '',
    password: '',
  };

  _validateInput() {
    let message;
    if (g.isEmpty(this.state.email)) {
      message = 'Please enter email address.';
    } else if (g.isEmpty(this.state.password) || this.state.password === '.') {
      message = 'Please enter password.';
    }

    if (g.isEmpty(message)) {
      return true;
    }

    this.props.actions.drop.showError('Sign In', message);
    return false;
  }

  _requestLogin(email, password) {
    const { actions } = this.props;

    apis.login(email, password).then(() => {
      actions.hud.hide();
      this._onLoggedIn();
    }).catch(() => {
      actions.hud.hide();
      actions.drop.showError('Sign In', 'Failed to login.');
    });
  }

  _onLoggedIn = () => {
    gAppStates.user.saveInfo();
    handler.main.user.loggedIn(true);
    this.props.actions.drop.showSuccess('Sign In', 'Sign in succeded.');
    navHandler.navback();

    // if (gUserInfo.smsVerified) {
    //   gUserInfo.saveSetting();
    //   dropHandler.showSuccess(consts.appName, 'Login succeded.');
    //   mainHandler.updateLoggedIn(gUserInfo.loggedIn);
    //   navHandler.pop(this.props.navRoot.key);
    //   setTimeout(() => {
    //     navHandler.animation(undefined);
    //     gAppStates.signContext.onLoggedIn && gAppStates.signContext.onLoggedIn();
    //     gAppStates.signContext.onLoggedIn = undefined;
    //   }, 300);
    // } else {
    //   navHandler.push(routekeys.smsMobile, this.props.navSign.key);
    // }
  }

  _onPressBack = () => {
    navHandler.navback();
  }

  _onPressSignup = () => {
    navHandler.navigate({ routeName: 'signUp' });
  }

  _onPressLogin = () => {
    if (!this._validateInput()) {
      return;
    }

    const { actions } = this.props;

    this.props.actions.hud.show('Signing In...');
    apis.login(this.state.email, this.state.password).then(() => {
      actions.hud.hide();
      this._onLoggedIn();
    }).catch(() => {
      actions.hud.hide();
      actions.drop.showError('Sign In', 'Failed to login.');
    });
  }

  _onPressLoginFB = () => {
    const { actions } = this.props;

    actions.hud.show('Signing In...');
    apis.loginFB().then(() => {
      actions.hud.hide();
      this._onLoggedIn();
    }).catch(() => {
      actions.hud.hide();
      actions.drop.showError('Sign In', 'Failed to login with facebook.');
    });
  }

  _renderTitle = () => (
    <View style={styles.title_bar} >
      <Button style={styles.btn_back} onPress={this._onPressBack} >
        <IOIcon name="ios-arrow-back" size={24} color="#4B4B4B" />
      </Button>
      <Text style={styles.txt_title}>SIGN IN</Text>
    </View>
  )

  _renderContent = () => (
    <View style={styles.content} >
      <KeyboardScrollView style={styles.scroll} contentStyle={styles.scroll_content} >
        { this._renderInput('Email Address', styles.view_edit,
          (text) => { this.state.email = text; }, (node) => { this.editEmail = node; }) }
        { this._renderInput('Password', [styles.view_edit, bs.mt_md],
          (text) => { this.state.password = text; }, (node) => { this.editPassword = node; }, { secureTextEntry: true }) }
        { this._renderButton('Login With Email', [styles.btn_login_email, bs.mt_md, bs.mb_sm], styles.txt_login_email, this._onPressLogin) }
        { this._renderOr() }
        { this._renderFbButton('Login with facebook', [styles.btn_login_fb, bs.mt_sm, bs.mb_sm], styles.txt_login_fb, this._onPressLoginFB) }
        { this._renderOr() }
        { this._renderButton('Sign Up', [styles.btn_signup, bs.mt_sm, bs.mb_md], styles.txt_signup, this._onPressSignup) }
        { this._renderPrivacy() }
      </KeyboardScrollView>
    </View>
  )

  _renderInput = (placeholder, style, onChangeText, onRef, otherProps) => (
    <View style={style} >
      <TextInput
        ref={onRef}
        placeholder={placeholder}
        placeholderTextColor="#4B95EF"
        autoCapitalize="none"
        autoCorrect={false}
        underlineColorAndroid="rgba(0,0,0,0)"
        style={styles.edit}
        onChangeText={onChangeText}
        {...otherProps}
      />
      <View style={styles.edit_underline} />
    </View>
  )
  _renderOr = () => (
    <View style={styles.view_or} >
      <View style={styles.view_or_separator} />
      <Text style={styles.txt_or} >or</Text>
      <View style={styles.view_or_separator} />
    </View>
  )
  _renderButton = (text, styleButton, styleText, onPress) => (
    <Button onPress={onPress} style={styleButton} >
      <Text style={styleText}>{text}</Text>
    </Button>
  )
  _renderFbButton = (text, styleButton, styleText, onPress) => (
    <Button onPress={onPress} style={styleButton} >
      <ZCIcon name="facebook" size={20} color="white" style={bs.mr_md} />
      <Text style={styleText} >{text}</Text>
    </Button>
  )
  _renderPrivacy = () => {
    const urlTerm = 'https://chune.com/term';
    const urlPrivacy = 'https://chune.com/privacy';
    const txtPrivacy = `By signing up, I agree to Chune's\n${urlTerm} and ${urlPrivacy}.`;
    return (
      <Hyperlink
        linkStyle={styles.txt_link}
        linkText={(url) => {
          if (url === urlTerm) { return 'Term of Service'; }
          if (url === urlPrivacy) { return 'Privacy Policy'; }
          return url;
        }}
      >
        <Text style={styles.txt_desc} >{txtPrivacy}</Text>
      </Hyperlink>
    );
  }

  render() {
    return (
      <View style={styles.container} >
        { this._renderTitle() }
        { this._renderContent() }
      </View>
    );
  }
}

const mapStateToProps = state => ({ // eslint-disable-line
});

const mapDispatchToProps = dispatch => ({
  actions: {
    drop: bindActionCreators(reduxActions.alert.drop, dispatch),
    hud: bindActionCreators(reduxActions.alert.hud, dispatch),
  },
});

export default connect(mapStateToProps, mapDispatchToProps)(SignIn);
