import { StyleSheet } from 'react-native';
import { basestyles as bs, consts, sizes } from '@theme';

const width = consts.phone ? sizes.screen.width - 32 * 2 : 450;
const height = consts.phone ? 40 : 50;

export default StyleSheet.create({
  container: {
    ...bs.layout.match_parent,
    backgroundColor: 'white',
  },
  content: {
    ...bs.layout.match_parent,
  },

  scroll: {
    ...bs.layout.match_parent,
    backgroundColor: 'transparent',
  },
  scroll_content: {
    ...bs.layout.match_parent,
    ...bs.align.center,
  },

  // title
  title_bar: {
    ...bs.align.center,
    ...bs.align.self.stretch,
    ...bs.statusbar.padding,
    backgroundColor: 'white',
  },
  txt_title: {
    ...bs.font.semibold,
    fontSize: 17,
    color: '#4B4B4B',
    ...bs.mt_xls,
    ...bs.mb_xls,
  },
  btn_back: {
    ...bs.layout.absolute,
    ...bs.align.center,
    left: 10,
    bottom: 0,
    top: sizes.statusBarHeight,
    ...bs.pl_xls,
    ...bs.pr_xls,
  },

  // edit
  view_edit: {
    width,
    height,
  },
  edit: {
    ...bs.layout.match_parent,
    ...bs.font.normal,
    fontSize: 15,
    color: '#222',
  },
  edit_underline: {
    height: 1.5,
    backgroundColor: '#4B95EF',
  },
  view_edit_row: {
    ...bs.layout.row,
  },
  view_edit_half: {
    ...bs.align.self.center,
    ...bs.ml_xls,
    ...bs.mr_xls,
    width: width / 2 - 10,
  },

  // button
  btn_login_email: {
    ...bs.align.center,
    width,
    height,
    backgroundColor: '#DDD',
    borderRadius: 4,
  },
  txt_login_email: {
    ...bs.font.normal,
    fontSize: 15,
    color: '#4B95EF',
  },
  btn_login_fb: {
    ...bs.layout.row,
    ...bs.align.center,
    width,
    height,
    backgroundColor: '#4469A8',
    borderRadius: 4,
  },
  txt_login_fb: {
    ...bs.font.bold,
    fontSize: 15,
    color: 'white',
  },
  btn_signup: {
    ...bs.align.center,
    width,
    height,
    backgroundColor: 'transparent',
    borderColor: '#4C96F2',
    borderWidth: 1.5,
    borderRadius: 4,
  },
  txt_signup: {
    ...bs.font.normal,
    fontSize: 15,
    color: '#4C96F2',
  },

  view_or: {
    ...bs.layout.row,
    ...bs.align.center,
    width: width + 10,
  },
  view_or_separator: {
    flex: 1,
    backgroundColor: '#767779',
    height: 1,
  },
  txt_or: {
    ...bs.font.semibold,
    fontSize: 14,
    color: '#767779',
    ...bs.ml_md,
    ...bs.mr_md,
  },

  txt_desc: {
    ...bs.align.self.center,
    ...bs.font.normal,
    fontSize: 14,
    color: '#222',
    textAlign: 'center',
  },
  txt_link: {
    ...bs.align.self.center,
    ...bs.font.normal,
    fontSize: 14,
    color: '#4C96F2',
    textAlign: 'center',
  },
});
