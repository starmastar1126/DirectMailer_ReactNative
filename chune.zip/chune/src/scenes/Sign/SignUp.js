import React, { Component } from 'react';
import { View, Text, TextInput } from 'react-native';
import { Button } from '@components/button';
import { ZCIcon, IOIcon } from '@components/icons';
import KeyboardScrollView from '@lib/KeyboardScrollView';
import g from '@common/global';
import { connect } from 'react-redux';
import { handler, actions as reduxActions, bindActionCreators } from '@redux';
import { gAppStates } from '@common';
import { apis } from '@lib';
import { consts } from '@theme';
import bs from '@theme/basestyles';
import styles from './SignUp.styles';

const { navigation: navHandler } = handler;

class SignUp extends Component {

  state = {
    email: '',
    password: '',
    fname: '',
    lname: '',
  };

  _validateInput() {
    let message;

    if (g.isEmpty(this.state.fname)) {
      message = 'Please enter first name.';
    } else if (g.isEmpty(this.state.lname)) {
      message = 'Please enter last name.';
    } else if (g.isEmpty(this.state.email)) {
      message = 'Please enter email address.';
    } else if (g.isEmpty(this.state.password) || this.state.password === '.') {
      message = 'Please enter password.';
    }
    if (g.isEmpty(message)) {
      return true;
    }
    this.props.actions.drop.showError(consts.appName, message);
    return false;
  }

  _onLoggedIn = () => {
    gAppStates.user.saveInfo();
    handler.main.user.loggedIn(true);
    this.props.actions.drop.showSuccess('Sign Up', 'Sign up succeded.');
    navHandler.popTo('app.main');

    // if (gUserInfo.smsVerified) {
    //   gUserInfo.saveSetting();
    //   mainHandler.updateLoggedIn(gUserInfo.loggedIn);
    //   navHandler.pop(this.props.navRoot.key);
    //   setTimeout(() => {
    //     navHandler.animation(undefined);
    //     gAppStates.signContext.onLoggedIn && gAppStates.signContext.onLoggedIn();
    //     gAppStates.signContext.onLoggedIn = undefined;
    //   }, 300);
    // } else {
    //   navHandler.push(routekeys.smsMobile, this.props.navSign.key);
    // }
  }

  _onPressBack = () => {
    navHandler.navback();
  }

  _onPressSignup = () => {
    if (!this._validateInput()) {
      return;
    }

    const { actions } = this.props;
    const params = {
      username: this.state.email,
      email: this.state.email,
      password: this.state.password,
      firstName: this.state.fname,
      lastName: this.state.lname,
    };

    actions.hud.show('Signing Up ...');
    apis.register(params).then(() => {
      actions.hud.hide();
      this._onLoggedIn();
    }).catch(() => {
      actions.hud.hide();
      actions.drop.showError('Sign Up', 'Failed to register user.');
    });
  }

  _onPressSignupFB = () => {
    const { actions } = this.props;

    actions.hud.show('Signing Up ...');
    apis.registerFB().then(() => {
      actions.hud.hide();
      this._onLoggedIn();
    }).catch(() => {
      actions.hud.hide();
      actions.drop.showError('Sign Up', 'Failed to sign up with facebook.');
    });
  }

  _renderTitle = () => (
    <View style={styles.title_bar} >
      <Button style={styles.btn_back} onPress={this._onPressBack} >
        <IOIcon name="ios-arrow-back" size={24} color="#4B4B4B" />
      </Button>
      <Text style={styles.txt_title}>SIGN UP</Text>
    </View>
  )

  _renderContent = () => (
    <View style={styles.content} >
      <KeyboardScrollView style={styles.scroll} contentStyle={styles.scroll_content} >
        { this._renderInput('First Name', styles.view_edit,
          (text) => { this.state.fname = text; }, (node) => { this.editFName = node; }, { autoCapitalize: 'words' }) }
        { this._renderInput('Last Name', [styles.view_edit, bs.mt_sm],
          (text) => { this.state.lname = text; }, (node) => { this.editLName = node; }, { autoCapitalize: 'words' }) }
        { this._renderInput('Email Address', [styles.view_edit, bs.mt_sm],
          (text) => { this.state.email = text; }, (node) => { this.editEmail = node; }) }
        { this._renderInput('Password', [styles.view_edit, bs.mt_sm],
          (text) => { this.state.password = text; }, (node) => { this.editPassword = node; }, { secureTextEntry: true }) }
        { this._renderButton('Sign Up with Email', [styles.btn_login_email, bs.mt_lg, bs.mb_md], styles.txt_login_email, this._onPressSignup) }
        { this._renderOr() }
        { this._renderFbButton('Sign Up with facebook', [styles.btn_login_fb, bs.mt_md, bs.mb_sm], styles.txt_login_fb, this._onPressSignupFB) }
      </KeyboardScrollView>
    </View>
  )

  _renderInput = (placeholder, style, onChangeText, onRef, otherProps) => (
    <View style={style} >
      <TextInput
        ref={onRef}
        placeholder={placeholder}
        placeholderTextColor="#4B95EF"
        autoCapitalize="none"
        autoCorrect={false}
        underlineColorAndroid="rgba(0,0,0,0)"
        style={styles.edit}
        onChangeText={onChangeText}
        {...otherProps}
      />
      <View style={styles.edit_underline} />
    </View>
  )
  _renderOr = () => (
    <View style={styles.view_or} >
      <View style={styles.view_or_separator} />
      <Text style={styles.txt_or} >or</Text>
      <View style={styles.view_or_separator} />
    </View>
  )
  _renderButton = (text, styleButton, styleText, onPress) => (
    <Button onPress={onPress} style={styleButton} >
      <Text style={styleText}>{text}</Text>
    </Button>
  )
  _renderFbButton = (text, styleButton, styleText, onPress) => (
    <Button onPress={onPress} style={styleButton} >
      <ZCIcon name="facebook" size={20} color="white" style={bs.mr_sm} />
      <Text style={styleText} >{text}</Text>
    </Button>
  )

  render() {
    return (
      <View style={styles.container} >
        { this._renderTitle() }
        { this._renderContent() }
      </View>
    );
  }
}

const mapStateToProps = state => ({ // eslint-disable-line
});

const mapDispatchToProps = dispatch => ({
  actions: {
    drop: bindActionCreators(reduxActions.alert.drop, dispatch),
    hud: bindActionCreators(reduxActions.alert.hud, dispatch),
  },
});

export default connect(mapStateToProps, mapDispatchToProps)(SignUp);
