import { StyleSheet } from 'react-native';
import { basestyles as bs, sizes, colors } from '@theme';

export default StyleSheet.create({
  container: {
    ...bs.layout.match_parent,
    ...bs.align.start_center,
    backgroundColor: 'black',
  },
  content: {
    ...bs.layout.match_parent,
  },

  // bottom bar
  view_menu_bottom: {
    ...bs.layout.absolute,
    left: 0,
    right: 0,
    top: sizes.screen.height - sizes.bottom.barTop - sizes.bottom.barHeight / 2,
    backgroundColor: 'transparent',
  },
  bar_bottom: {
    ...bs.align.start_center,
    ...bs.align.self.stretch,
    height: sizes.bottom.barHeight,
    marginTop: sizes.bottom.barTop,
    backgroundColor: colors.bottom.barBackground,
  },
  bar_bottom_btn: {
    ...bs.layout.absolute,
    ...bs.align.center,
    left: 0,
    right: 0,
    top: 0,
  },
  btn_bottom_menu: {
    ...bs.align.center,
    width: sizes.bottom.logoSize,
    height: sizes.bottom.logoSize,
    borderRadius: sizes.bottom.logoSize / 2,
    borderWidth: 1.5,
    borderColor: 'white',
    backgroundColor: '#1FC800',
  },
  img_bottom_logo: {
    width: sizes.bottom.logoImageSize,
    height: sizes.bottom.logoImageSize,
    resizeMode: 'stretch',
  },
  view_bottom_content: {
    ...bs.align.self.stretch,
    backgroundColor: '#eee',
    height: 200,
  },
  view_bottom_overlay: {
    ...bs.layout.absolute_full,
    backgroundColor: 'transparent',
  },
});
