import React, { Component } from 'react';
import { View, Animated, PanResponder, Image } from 'react-native';
import { Button } from '@components/button';
import { Navigators } from '@routes';
import { addNavigationHelpers } from 'react-navigation';
import { connect } from 'react-redux';
import { sizes, images } from '@theme';
import styles from './Main.styles';

class Main extends Component {
  constructor(props) {
    super(props);

    this.state = {
      dataSource: null,
      openedBottom: false,
      animBottomTransY: new Animated.Value(0),
      frmBottom: { height: 0 },
    };

    this.panMoveCb = Animated.event([{ dy: this.state.animBottomTransY }]);
    this.panResponder = PanResponder.create({
      onMoveShouldSetResponderCapture: () => true,
      onMoveShouldSetPanResponderCapture: this._onMoveShouldSetPanResponderCapture,
      onPanResponderGrant: this._onPanResponderGrant,
      onPanResponderMove: this._onPanResponderMove,
      onPanResponderRelease: this._onPanResponderRelease,
      onPanResponderTerminate: this._onPanResponderRelease,
    });
  }

  visibleBottomMenu(visible: Boolean, force: Boolean = false) {
    if (!force && this.state.openedBottom === visible) return;

    const height: Number = this.state.frmBottom.height - sizes.bottom.logoSize / 2;

    this.setState({ openedBottom: visible });
    Animated.spring(this.state.animBottomTransY, {
      toValue: visible ? -height : 0,
      duration: 500,
    }).start();
  }

  _onMoveShouldSetPanResponderCapture = (event, gs) => {
    // if (this.state.openedBottom) return true;
    // if (gs.moveY >= sizes.screen.height - sizes.bottom.barHeight / 2) {
    //   return true;
    // }
    // return false;
    gs;
    return true;
  }
  _onPanResponderGrant = () => {
  }
  _onPanResponderMove = (event, gs) => {
    const height: Number = this.state.frmBottom.height - sizes.bottom.logoSize / 2;
    const param = { dy: gs.dy };
    if (this.state.openedBottom) {
      param.dy = Math.min(0, Math.max(-height, -height + param.dy));
    } else {
      param.dy = Math.min(0, Math.max(-height, param.dy));
    }
    this.panMoveCb(param);
  }
  _onPanResponderRelease = (event, gs) => {
    const height: Number = this.state.frmBottom.height;
    if (this.state.openedBottom) {
      const dy = gs.dy;
      if (dy < height * 0.35) {
        this.visibleBottomMenu(true, true);
      } else {
        this.visibleBottomMenu(false, true);
      }
    } else {
      const dy = -gs.dy;
      if (dy > height * 0.35) {
        this.visibleBottomMenu(true, true);
      } else {
        this.visibleBottomMenu(false, true);
      }
    }
  }

  _onPressMenu = () => {
    // navHandler.pop();
    this.visibleBottomMenu(true);
  }
  _onPressBottomOverlay = () => {
    this.visibleBottomMenu(false);
  }

  _renderNavigator = () => {
    const navigation = addNavigationHelpers({
      dispatch: this.props.dispatch,
      // state: this.props.navClash,
    });

    return (
      <View style={styles.content} >
        <Navigators.Clash
          navigation={navigation}
        />
      </View>
    );
  }

  _renderBottomMenu = () => (
    <Animated.View
      pointerEvents="box-none"
      style={[
        styles.view_menu_bottom,
        { transform: [{ translateY: this.state.animBottomTransY }] },
      ]}
      onLayout={(e) => { this.state.frmBottom = e.nativeEvent.layout; }}
      {...this.panResponder.panHandlers}
    >
      <View style={styles.bar_bottom} />
      { this._renderBottomContent() }
      <View style={styles.bar_bottom_btn} pointerEvents="box-none" >
        <Button style={styles.btn_bottom_menu} onPress={this._onPressMenu}>
          <Image source={images.ic_bottom_logo} style={styles.img_bottom_logo} />
        </Button>
      </View>
    </Animated.View>
  )
  _renderBottomContent = () => (
    <View style={styles.view_bottom_content} />
  )
  _renderBottomOverlay = () => {
    if (this.state.openedBottom) {
      return (
        <Button style={styles.view_bottom_overlay} activeOpacity={1} onPress={this._onPressBottomOverlay} />
      );
    }
    return null;
  }

  render() {
    return (
      <View style={styles.container} >
        { this._renderNavigator() }
        { this._renderBottomOverlay() }
        { this._renderBottomMenu() }
      </View>
    );
  }
}

const mapStateToProps = state => ({
  // navClash: state.navClash,
});

const mapDispatchToProps = dispatch => ({ // eslint-disable-line
});

export default connect(mapStateToProps, mapDispatchToProps)(Main);
