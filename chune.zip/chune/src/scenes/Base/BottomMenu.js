import React, { Component } from 'react';
import {
  View, Keyboard, ListView, Text, Image,
  TextInput, Animated,
} from 'react-native';
import { Button } from '@components/button';
import { IOIcon } from '@components/icons';
import Video from 'react-native-video';
import PopupDialog, { DialogButton } from 'react-native-popup-dialog';
import _ from 'lodash';
import moment from 'moment';
import { connect } from 'react-redux';
import { gAppStates } from '@common';
import { apis } from '@lib';
import { MDClash, MDClashOpponent, MDClashRound, MDComment } from '@model';
import { handler } from '@redux';
import { sizes, consts } from '@theme';
import styles from './EventDetail.styles';

const { navigation: navHandler } = handler;

export default (props) => (
  <Button {...otherProps} style={style} >
    <Text style={textStyle} >{text}</Text>
  </Button>
);
