import { StyleSheet } from 'react-native';
import { basestyles as bs, sizes, colors } from '@theme';

export default StyleSheet.create({

  // bottom bar
  bottom: {
    ...bs.align.start_center,
    ...bs.align.self.stretch,
    height: sizes.setting.bottomHeight,
    marginTop: -(sizes.setting.bottomHeight - sizes.setting.bottomBarHeight),
  },
  bar_bottom: {
    ...bs.align.start_center,
    ...bs.align.self.stretch,
    ...bs.layout.absolute,
    left: 0,
    right: 0,
    bottom: 0,
    height: sizes.setting.bottomBarHeight,
    backgroundColor: colors.setting.navBackground,
  },
  btn_bottom_menu: {
    borderWidth: 1,
    borderColor: colors.setting.logoBorder,
    borderRadius: sizes.setting.logoSize / 2,
    width: sizes.setting.logoSize,
    height: sizes.setting.logoSize,
    backgroundColor: colors.setting.logoBackground,
  },
});
