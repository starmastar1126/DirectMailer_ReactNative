import React, { Component } from 'react';
import { View, ListView, Text } from 'react-native';
import { Button } from '@components/button';
import { IOIcon } from '@components/icons';
import { connect } from 'react-redux';
import { gAppStates } from '@common';
import { handler, navkeys } from '@redux';
import g from '@global';
import { consts } from '@theme';
import styles from './VoteResult.styles';

const { navigation: navHandler } = handler;
const { voteDate } = consts;

class VoteResult extends Component {

  constructor(props) {
    super(props);

    this.state = {
      dataSource: null,
    };

    this.jerks = gAppStates.jerks;
    this.ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
    this._buildDataSource(this.jerks);
  }

  _buildDataSource(jerks: Array<Object>) {
    this.state.dataSource = this.ds.cloneWithRows(jerks);
  }

  _onPressBack = () => {
    // navHandler.navback(null, navkeys.clash);
    navHandler.popToIndex(0, navkeys.clash);
  }

  _onPressShare = () => {
  }

  _renderTitle = () => (
    <View style={styles.title_bar} >
      <View style={styles.view_title} >
        <Text style={styles.txt_title}>Thanks for your vote!</Text>
        <Text style={styles.txt_title_at}>WINNER WILL BE ANNOUNCED IN</Text>
      </View>
      <Button style={styles.btn_back} onPress={this._onPressBack} >
        <IOIcon name="ios-arrow-back" size={24} color="#222" />
      </Button>
    </View>
  )

  _renderHour = () => {
    let remain: Number = parseInt((voteDate.getTime() - (new Date()).getTime()) / 1000, 10);
    const days: Number = parseInt(remain / (3600 * 24), 10);
    remain -= days * 3600 * 24;
    const hours: Number = parseInt(remain / 3600, 10);
    remain -= hours * 3600;
    const minutes: Number = parseInt(remain / 60, 10);
    remain -= minutes * 60;
    const seconds: Number = remain;
    const formatDesc = (count, unit) => `${unit}${count > 1 ? 'S' : ''}`;

    let nums: Array, descs: Array;
    if (days > 0) {
      nums = [days, hours, minutes];
      descs = [formatDesc(days, 'DAY'), formatDesc(hours, 'HOUR'), formatDesc(minutes, 'MINUTE')];
    } else if (hours > 0) {
      nums = [hours, minutes];
      descs = [formatDesc(hours, 'HOUR'), formatDesc(minutes, 'MINUTE')];
    } else {
      nums = [minutes, seconds];
      descs = [formatDesc(minutes, 'MINUTE'), formatDesc(seconds, 'SECOND')];
    }
    const hourViews = nums.map((info, index) => (
      <View key={`hour-view-${index + 1}`} style={styles.view_hour_val} >
        <Text style={styles.txt_hour} >{nums[index]}</Text>
        <Text style={styles.txt_hour_desc} >{descs[index]}</Text>
      </View>
    ));

    return (
      <View style={styles.view_hour} >
        { hourViews }
      </View>
    );
  }

  _renderList = () => (
    <ListView
      enableEmptySections
      style={styles.list}
      dataSource={this.state.dataSource}
      renderRow={this._renderRow}
    />
  )
  _renderRow = (info, row, index) => {
    index = parseInt(index, 0);
    let place;
    if (index === 0) place = 'IN THE LEAD';
    else if (index === 1) place = '2nd Runner Up';
    else if (index === 2) place = '3rd Runner Up';
    else place = `${index + 1}th Runner Up`;

    return (
      <View style={styles.row_jerk} >
        <View style={styles.row_jerk_cont} >
          <Text style={styles.txt_row_cont} >CONTESTANT</Text>
          <Text style={styles.txt_row_cont_val}>{`#0${index < 9 ? '0' : ''}${index + 1}`}</Text>
          <Text style={styles.txt_row_name} >{info.name}</Text>
          <Text style={styles.txt_row_desc} >{info.description}</Text>
        </View>
        <View style={styles.row_separator} />
        <View style={styles.view_row_status} >
          <Text style={styles.txt_row_status} >{ place }</Text>
        </View>
      </View>
    );
  }

  _renderShare = () => {
    const remain: Number = parseInt((voteDate.getTime() - (new Date()).getTime()) / 1000, 10);
    if (remain > 0) return null;
    return (
      <Button style={styles.btn_share} onPress={this._onPressShare} >
        <Text style={styles.txt_share} >Share Results on Facebook</Text>
      </Button>
    );
  }

  render() {
    return (
      <View style={styles.container} >
        { this._renderTitle() }

        <View style={styles.content} >
          { this._renderHour() }
          { this._renderList() }
          { this._renderShare() }
        </View>
      </View>
    );
  }
}

const mapStateToProps = state => ({ // eslint-disable-line
});

const mapDispatchToProps = dispatch => ({ // eslint-disable-line
});

export default connect(mapStateToProps, mapDispatchToProps)(VoteResult);
