import React, { Component } from 'react';
import { View, Text, TextInput } from 'react-native';
import { Button } from '@components/button';
import { IOIcon } from '@components/icons';
import KeyboardScrollView from '@lib/KeyboardScrollView';
import { connect } from 'react-redux';
import { gAppStates } from '@common';
import { apis } from '@lib';
import g from '@global';
import { handler, navkeys, actions as reduxActions, bindActionCreators } from '@redux';
import { MDJudge } from '@model';
import bs from '@theme/basestyles';
import styles from './Invite.styles';

const { navigation: navHandler } = handler;

class Invite extends Component {

  editEmails: Array = [];
  state = {
    emails: [],
  }

  _validateInput(): Array<String> {
    const { actions } = this.props;
    const judge: MDJudge = gAppStates.judge;
    const emails = [];
    for (let i = 0; i < judge.judgeQty - 1; i += 1) {
      const email = this.state.emails[i];
      if (email && email.length > 0) {
        emails.push(email);
      }
    }

    if (emails.length === 0) {
      actions.drop.showError('Invite', 'Please enter email or phone.');
      return null;
    }
    return emails;
  }

  _onPressBack = () => {
    navHandler.navback(null, navkeys.clash);
  }

  _onPressSend = () => {
    const emails = this._validateInput();
    if (!emails) return;

    const { actions } = this.props;
    actions.hud.show('Requesting...');
    apis.inviteJudges(emails).then(() => {
      actions.hud.hide();
      actions.drop.showSuccess('Invite', 'Invite succeded.');
      navHandler.navback(null, navkeys.clash);
    }).catch(() => {
      actions.hud.hide();
      actions.drop.showError('Invite', 'Invite failed');
    });
  }

  _renderTitle = () => {
    const judge: MDJudge = gAppStates.judge;
    return (
      <View style={styles.title_bar} >
        <View style={styles.view_title} >
          <Text style={styles.txt_title}>INVITE OTHER JUDGES</Text>
          <Text style={styles.txt_title_at}>{g.formatCount(judge.judgeQty - 1, ' Invite')}</Text>
        </View>
        <Button style={styles.btn_back} onPress={this._onPressBack} >
          <IOIcon name="ios-arrow-back" size={24} color="#222" />
        </Button>
      </View>
    );
  }

  _renderInvites = () => {
    const judge: MDJudge = gAppStates.judge;
    const inputs = [];
    for (let i = 0; i < judge.judgeQty - 1; i += 1) {
      const input = this._renderInput(`invite.input.${i}`, 'Enter phone or email', [styles.view_edit, bs.mb_md],
        (text) => { this.state.emails[i] = text; }, (node) => { this.editEmails[i] = node; });
      inputs.push(input);
    }

    return (
      <View style={styles.view_invites} >
        <KeyboardScrollView style={styles.scroll} contentStyle={styles.scroll_content} >
          { inputs }
        </KeyboardScrollView>
      </View>
    );
  }

  _renderInput = (key, placeholder, style, onChangeText, onRef, otherProps) => (
    <View style={style} key={key} >
      <TextInput
        ref={onRef}
        placeholder={placeholder}
        placeholderTextColor="#4B95EF"
        autoCapitalize="none"
        autoCorrect={false}
        underlineColorAndroid="rgba(0,0,0,0)"
        style={styles.edit}
        onChangeText={onChangeText}
        {...otherProps}
      />
      <View style={styles.edit_underline} />
    </View>
  )

  _renderSend = () => (
    <Button style={styles.btn_send} onPress={this._onPressSend} >
      <Text style={styles.txt_send} >Send Invites</Text>
    </Button>
  )

  render() {
    return (
      <View style={styles.container} >
        { this._renderTitle() }

        <View style={styles.content} >
          { this._renderInvites() }
          { this._renderSend() }
        </View>
      </View>
    );
  }
}

const mapStateToProps = state => ({ // eslint-disable-line
});

const mapDispatchToProps = dispatch => ({ // eslint-disable-line
  actions: {
    drop: bindActionCreators(reduxActions.alert.drop, dispatch),
    hud: bindActionCreators(reduxActions.alert.hud, dispatch),
  },
});

export default connect(mapStateToProps, mapDispatchToProps)(Invite);
