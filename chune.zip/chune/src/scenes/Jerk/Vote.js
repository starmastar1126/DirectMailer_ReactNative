import React, { Component } from 'react';
import { View, ListView, Text } from 'react-native';
import { Button } from '@components/button';
import { IOIcon } from '@components/icons';
import moment from 'moment';
import StarRating from 'react-native-star-rating';
import { connect } from 'react-redux';
import { handler, navkeys, shallowEqual } from '@redux';
import { gAppStates } from '@common';
import { apis } from '@lib';
import g from '@global';
import { MDCompetitor, MDJudge } from '@model';
import { consts } from '@theme';
import styles from './Vote.styles';

const { navigation: navHandler } = handler;
const { voteDate } = consts;

console.log(voteDate.toString(), moment(voteDate).format('hA, ddd. MMM D').toUpperCase());

class Vote extends Component {

  constructor(props) {
    super(props);

    this.state = {
      dataSource: null,
    };

    this.jerks = [
      { rating1: 3, rating2: 3 },
      { rating1: 3, rating2: 3 },
    ];

    this.ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 || !shallowEqual(r1.ratings, r2.ratings) });
    this._buildDataSource([]);
  }

  componentDidMount() {
    this._loadJerks();
  }

  _loadJerks() {
    apis.getCompetitors().then((res) => {
      const competitors = MDCompetitor.parseList(res);
      this._buildDataSource(competitors);
      this.forceUpdate();
    }).catch(() => {});
  }

  _buildDataSource(jerks: Array<Object>) {
    gAppStates.jerks = jerks;
    this.jerks = jerks;
    this.state.dataSource = this.ds.cloneWithRows(jerks);
  }

  _onPressBack = () => {
    navHandler.navback(null, navkeys.clash);
  }
  _onPressInvite = () => {
    navHandler.navigate({ routeName: 'jerkInvite' }, navkeys.clash);
  }

  _onPressSubmit = () => {
    apis.doneVote(gAppStates.user.userId).then(() => {
      apis.isJudge(gAppStates.user.userId).then(() => {}).catch(() => {});
    }).catch(() => {});
    navHandler.navigate({ routeName: 'jerkVoteResult' }, navkeys.clash);
  }

  _onChangeRate = (index, category, rating) => {
    const jerk = this.jerks[index];
    apis.vote(jerk._id, gAppStates.user.userId, rating, category).then(() => {
      this.jerks[index].ratings[category] = rating;
      this._buildDataSource(this.jerks);
      this.forceUpdate();
    }).catch(() => {});
  }

  _renderTitle = () => {
    const strDate = moment(voteDate).format('hA, ddd. MMM D').toUpperCase();
    return (
      <View style={styles.title_bar} >
        <View style={styles.view_title} >
          <Text style={styles.txt_title}>JERK OFF!</Text>
          <Text style={styles.txt_title_at} numberOfLines={0}>{`VOTING STARTS AT ${strDate}`}</Text>
        </View>
        <Button style={styles.btn_back} onPress={this._onPressBack} >
          <IOIcon name="ios-arrow-back" size={24} color="#222" />
        </Button>
      </View>
    );
  }

  _renderList = () => (
    <ListView
      enableEmptySections
      style={styles.list}
      dataSource={this.state.dataSource}
      renderRow={this._renderRow}
    />
  )
  _renderRow = (info, row, index) => {
    index = parseInt(index, 10);

    return (
      <View style={styles.row_jerk} >
        <View style={styles.row_jerk1} >
          <View style={styles.row_jerk_cont} >
            <View style={styles.row_jerk_cont1} >
              <Text style={styles.txt_row_cont} >CONTESTANT</Text>
              <Text style={styles.txt_row_cont_val}>{`#0${index < 9 ? '0' : ''}${index + 1}`}</Text>
            </View>
            <Text style={styles.txt_row_name} >{info.name}</Text>
            <Text style={styles.txt_row_name} >{info.description}</Text>
          </View>

          <View style={styles.row_jerk_rate} >
            <Text style={styles.txt_jerk_rate} >PRESENTATION</Text>
            { this._renderRating(info, index, 'presentation') }
            <Text style={styles.txt_jerk_rate} >TASTE</Text>
            { this._renderRating(info, index, 'taste') }
          </View>
        </View>
        <View style={styles.row_separator} />
      </View>
    );
  }

  _renderRating = (info: Object, index: Number, category: String) => (
    <StarRating
      disabled={false}
      emptyStar={'ios-star'}
      fullStar={'ios-star'}
      halfStar={'ios-star-half'}
      iconSet={'Ionicons'}
      maxStars={5}
      rating={info.ratings[category]}
      selectedStar={(rating) => { this._onChangeRate(index, category, rating); }}
      starColor="#FFDD00"
      emptyStarColor="#D8D8D8"
      starSize={20}
      buttonStyle={{ marginHorizontal: 2 }}
    />
  )

  _renderInvite = () => {
    const judge: MDJudge = gAppStates.judge;
    if (judge.judgeQty <= 1) return null;
    return (
      <Button style={styles.btn_invite} onPress={this._onPressInvite} >
        <Text style={styles.txt_invite1} >INVITE OTHER JUDGES</Text>
        <Text style={styles.txt_invite2} >{g.formatCount(judge.judgeQty - 1, ' Invite')}</Text>
      </Button>
    );
  }

  _renderSubmit = () => {
    const remain: Number = (voteDate.getTime() - (new Date()).getTime()) / 1000;
    if (remain <= 0) return null;

    return (
      <Button style={styles.btn_submit} onPress={this._onPressSubmit} >
        <Text style={styles.txt_submit} >Done Voting</Text>
      </Button>
    );
  }

  render() {
    return (
      <View style={styles.container} >
        { this._renderTitle() }

        <View style={styles.content} >
          { this._renderInvite() }
          { this._renderList() }
          { this._renderSubmit() }
        </View>
      </View>
    );
  }
}

const mapStateToProps = state => ({ // eslint-disable-line
});

const mapDispatchToProps = dispatch => ({ // eslint-disable-line
});

export default connect(mapStateToProps, mapDispatchToProps)(Vote);
