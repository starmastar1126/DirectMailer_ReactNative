import { StyleSheet } from 'react-native';
import { basestyles as bs, consts, sizes } from '@theme';

const width = consts.phone ? sizes.screen.width - 32 * 2 : 450;
const height = consts.phone ? 40 : 50;

export default StyleSheet.create({
  container: {
    ...bs.layout.match_parent,
    ...bs.align.start_center,
    backgroundColor: 'white',
  },
  content: {
    ...bs.layout.match_parent,
    ...bs.align.start_center,
    ...bs.mt_xs,
    marginBottom: sizes.bottom.logoSize / 2 + 10,
    backgroundColor: 'transparent',
  },

  // title
  title_bar: {
    ...bs.align.center,
    ...bs.align.self.stretch,
    ...bs.statusbar.padding,
    backgroundColor: 'white',
  },
  view_title: {
    ...bs.align.center,
    ...bs.align.self.stretch,
    marginTop: 6,
    marginBottom: 6,
    backgroundColor: 'transparent',
  },
  txt_title: {
    ...bs.font.bold,
    fontSize: 17,
    color: '#222',
  },
  txt_title_at: {
    ...bs.font.semibold,
    fontSize: 12,
    color: '#222',
  },
  btn_back: {
    ...bs.layout.absolute,
    ...bs.align.center,
    left: 10,
    bottom: 0,
    top: sizes.statusBarHeight,
    paddingLeft: 8,
    paddingRight: 8,
  },

  view_invites: {
    ...bs.layout.match_parent,
  },
  scroll: {
    ...bs.layout.match_parent,
    backgroundColor: 'transparent',
  },
  scroll_content: {
    ...bs.layout.match_parent,
    ...bs.align.start_center,
  },

  // edit
  view_edit: {
    width,
    height,
  },
  edit: {
    ...bs.layout.match_parent,
    ...bs.font.normal,
    fontSize: 15,
    color: '#222',
  },
  edit_underline: {
    height: 1.5,
    backgroundColor: '#4B95EF',
  },

  // submit
  btn_send: {
    ...bs.align.self.stretch,
    ...bs.align.center,
    ...bs.mh_lg,
    height: 44,
    borderRadius: 6,
    backgroundColor: '#4CCA00',
  },
  txt_send: {
    ...bs.font.semibold,
    fontSize: 13,
    color: 'white',
  },
});
