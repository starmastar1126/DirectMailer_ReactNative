import { StyleSheet } from 'react-native';
import { basestyles as bs, sizes } from '@theme';

export default StyleSheet.create({
  container: {
    ...bs.layout.match_parent,
    ...bs.align.start_center,
    backgroundColor: 'white',
  },
  content: {
    ...bs.layout.match_parent,
    ...bs.align.start_center,
    ...bs.mt_xs,
    marginBottom: sizes.bottom.logoSize / 2 + 10,
    backgroundColor: 'transparent',
  },

  // title
  title_bar: {
    ...bs.align.center,
    ...bs.align.self.stretch,
    ...bs.statusbar.padding,
    backgroundColor: 'white',
  },
  view_title: {
    ...bs.align.center,
    ...bs.align.self.stretch,
    marginTop: 6,
    marginBottom: 6,
    backgroundColor: 'transparent',
  },
  txt_title: {
    ...bs.font.bold,
    fontSize: 17,
    color: '#222',
  },
  txt_title_at: {
    ...bs.font.semibold,
    fontSize: 12,
    color: '#222',
  },
  btn_back: {
    ...bs.layout.absolute,
    ...bs.align.center,
    left: 10,
    bottom: 0,
    top: sizes.statusBarHeight,
    paddingLeft: 8,
    paddingRight: 8,
  },

  // list
  list: {
    ...bs.layout.match_parent,
    ...bs.mv_xs,
  },
  row_jerk: {
    ...bs.layout.match_parent,
  },
  row_jerk1: {
    ...bs.layout.row,
    ...bs.align.self.stretch,
    ...bs.align.between_center,
    ...bs.mh_sm,
    ...bs.mt_xs,
  },
  row_jerk_cont: {
    ...bs.layout.match_parent,
    ...bs.align.center_start,
  },
  row_jerk_cont1: {
    ...bs.align.center,
  },
  txt_row_cont: {
    ...bs.font.semibold,
    fontSize: 12,
    color: '#D0011B',
  },
  txt_row_cont_val: {
    ...bs.font.bold,
    fontSize: 30,
    color: '#FF0000',
  },
  txt_row_name: {
    ...bs.font.normal,
    fontSize: 12,
    color: '#000',
  },
  row_separator: {
    ...bs.align.self.stretch,
    ...bs.mh_lg,
    ...bs.mt_xs,
    height: 1.5,
    backgroundColor: '#979797',
  },
  row_jerk_rate: {
    ...bs.align.center,
    ...bs.ml_xs,
  },
  txt_jerk_rate: {
    ...bs.font.semibold,
    fontSize: 12,
    color: '#000',
    paddingVertical: 3,
  },

  // submit
  btn_submit: {
    ...bs.align.self.stretch,
    ...bs.align.center,
    ...bs.mh_lg,
    height: 44,
    borderRadius: 6,
    backgroundColor: '#1FC800',
  },
  txt_submit: {
    ...bs.font.semibold,
    fontSize: 13,
    color: 'white',
  },

  // judge
  btn_invite: {
    ...bs.align.self.stretch,
    ...bs.align.center,
    ...bs.pv_xls,
    backgroundColor: '#F8EC07',
  },
  txt_invite1: {
    ...bs.font.semibold,
    fontSize: 15,
    color: '#000',
  },
  txt_invite2: {
    ...bs.font.normal,
    fontSize: 15,
    color: '#000',
  },
});
