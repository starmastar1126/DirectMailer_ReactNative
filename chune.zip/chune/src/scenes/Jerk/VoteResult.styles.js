import { StyleSheet } from 'react-native';
import { basestyles as bs, sizes } from '@theme';

export default StyleSheet.create({
  container: {
    ...bs.layout.match_parent,
    ...bs.align.start_center,
    backgroundColor: 'white',
  },
  content: {
    ...bs.layout.match_parent,
    ...bs.align.start_center,
    ...bs.mt_xs,
    marginBottom: sizes.bottom.logoSize / 2 + 10,
    backgroundColor: 'transparent',
  },

  // title
  title_bar: {
    ...bs.align.center,
    ...bs.align.self.stretch,
    ...bs.statusbar.padding,
    backgroundColor: 'white',
  },
  view_title: {
    ...bs.align.center,
    ...bs.align.self.stretch,
    marginTop: 6,
    marginBottom: 6,
    backgroundColor: 'transparent',
  },
  txt_title: {
    ...bs.font.bold,
    fontSize: 17,
    color: '#222',
  },
  txt_title_at: {
    ...bs.font.semibold,
    fontSize: 12,
    color: '#222',
  },
  btn_back: {
    ...bs.layout.absolute,
    ...bs.align.center,
    left: 10,
    bottom: 0,
    top: sizes.statusBarHeight,
    paddingLeft: 8,
    paddingRight: 8,
  },

  // hour
  view_hour: {
    ...bs.layout.row,
    ...bs.align.center,
    ...bs.pv_xls,
    ...bs.ph_sm,
    borderRadius: 6,
    backgroundColor: '#000',
  },
  view_hour_val: {
    ...bs.align.center,
    ...bs.mh_sm,
    backgroundColor: 'transparent',
  },
  txt_hour: {
    ...bs.font.bold,
    fontSize: 30,
    color: 'white',
  },
  txt_hour_desc: {
    ...bs.font.normal,
    fontSize: 12,
    color: 'white',
  },

  // list
  list: {
    ...bs.layout.match_parent,
    ...bs.mv_xs,
  },
  row_jerk: {
    ...bs.layout.match_parent,
  },
  row_jerk_cont: {
    ...bs.align.center,
    ...bs.mh_sm,
    ...bs.mt_xs,
  },
  txt_row_cont: {
    ...bs.font.semibold,
    fontSize: 12,
    color: '#D0011B',
  },
  txt_row_cont_val: {
    ...bs.font.bold,
    fontSize: 30,
    color: '#FF0000',
  },
  txt_row_name: {
    ...bs.font.normal,
    fontSize: 12,
    color: '#000',
  },
  txt_row_desc: {
    ...bs.font.normal,
    fontSize: 12,
    color: '#000',
    textAlign: 'center',
  },
  row_separator: {
    ...bs.align.self.stretch,
    ...bs.mh_lg,
    ...bs.mt_xs,
    height: 1.5,
    backgroundColor: '#979797',
  },
  view_row_status: {
    ...bs.layout.absolute,
    paddingRight: 8,
    paddingLeft: 18,
    paddingVertical: 4,
    left: -10,
    top: 15,
    borderRadius: 6,
    backgroundColor: '#D8D8D8',
  },
  txt_row_status: {
    ...bs.font.normal,
    fontSize: 11,
    color: '#828282',
  },

  // submit
  btn_share: {
    ...bs.align.self.stretch,
    ...bs.align.center,
    ...bs.mh_lg,
    height: 44,
    borderRadius: 6,
    backgroundColor: '#000FD9',
  },
  txt_share: {
    ...bs.font.semibold,
    fontSize: 13,
    color: 'white',
  },
});
