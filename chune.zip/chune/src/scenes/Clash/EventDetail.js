import React, { Component } from 'react';
import {
  View, Keyboard, ListView, Text, Image,
  TextInput, Animated,
} from 'react-native';
import { Button } from '@components/button';
import { IOIcon } from '@components/icons';
import Video from 'react-native-video';
import PopupDialog, { DialogButton } from 'react-native-popup-dialog';
import _ from 'lodash';
import moment from 'moment';
import { connect } from 'react-redux';
import { gAppStates } from '@common';
import { apis } from '@lib';
import { MDClash, MDClashOpponent, MDClashRound, MDComment } from '@model';
import { handler, navkeys } from '@redux';
import { sizes, consts } from '@theme';
import styles from './EventDetail.styles';

const { navigation: navHandler } = handler;

const EventStates: Object = {
  waiting: 'waiting',
  waitReady: 'waitStart',
  waitPart: 'waitParticipate',
  roundLeft: 'roundLeft',
  roundWait: 'roundWait',
  roundRight: 'roundRight',
  roundVote: 'roundVote',
  eventEnd: 'eventEnd',
};
const WAIT_SECS: Number = 30;
const WAIT_COUNTDOWN: Number = 120;

class EventDetail extends Component {

  state: Object = {
    eventState: EventStates.waitPart,
    eventRound: 0,
    remainSecs: 0,
    dsComment1: null,
    dsComment2: null,
    videoLeftReady: false,
    videoRightReady: false,
    commentLeft: '',
    commentRight: '',
    keyboardHeight: 0,
    animSearchBottom: new Animated.Value(0),
    animSearchLeftFlex: new Animated.Value(1),
    animSearchRightFlex: new Animated.Value(1),
    animPlayerLeftOpacity: new Animated.Value(0),
    animPlayerRightOpacity: new Animated.Value(0),
  };
  ds: ListView.DataSource = null;
  timer: * = null;
  canVote: Boolean = false;
  roundWinner: String = null;
  roundLooser: String = null;

  constructor(props) {
    super(props);

    this.ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
    this._buildDataSource([], []);

    const state = this._getEventState();
    this.state.eventState = state.eventState;
    this.state.remainSecs = state.remainSecs;
  }

  componentDidMount() {
    this._loadComments();
    this._startUpdateTimer();

    this.keyboardListeners = [];
    this.keyboardListeners.push(Keyboard.addListener('keyboardWillShow', this._onKeyboardShow));
    this.keyboardListeners.push(Keyboard.addListener('keyboardDidShow', this._onKeyboardShow));
    this.keyboardListeners.push(Keyboard.addListener('keyboardWillChangeFrame', this._onKeyboardShow));
    this.keyboardListeners.push(Keyboard.addListener('keyboardDidChangeFrame', this._onKeyboardShow));
    this.keyboardListeners.push(Keyboard.addListener('keyboardWillHide', this._onKeyboardHide));
    this.keyboardListeners.push(Keyboard.addListener('keyboardDidHide', this._onKeyboardHide));
  }

  componentWillUnmount() {
    this._endUpdateTimer();

    this.keyboardListeners.forEach((listener) => { listener.remove(); });
  }

  _buildDataSource(comments1, comments2) {
    if (comments1) {
      this.state.dataSource1 = this.ds.cloneWithRows(comments1);
    }
    if (comments2) {
      this.state.dataSource2 = this.ds.cloneWithRows(comments2);
    }
  }

  _getEventState(): Object {
    const info: MDClash = gAppStates.clashContext.event;
    const startDate: Date = info.startDate;
    const curDate: Date = new Date();
    const remain: Number = parseInt((startDate.getTime() - curDate.getTime()) / 1000, 10);
    const roundCount: Number = info.rounds.length;

    // wait for round start time
    if (remain > WAIT_COUNTDOWN) {
      return {
        remainSecs: remain,
        eventState: EventStates.waiting,
        eventRound: 1,
      };
    }

    // count down round start
    if (remain > 0) {
      return {
        remainSecs: remain,
        eventState: EventStates.waitReady,
        eventRound: 1,
      };
    }

    let elapsed: Number = -remain;
    let i: Number;

    for (i = 0; i < roundCount; i += 1) {
      const roundInfo: MDClashRound = info.rounds[i];
      const totalSecs: Number = roundInfo.duration * 2 + WAIT_SECS * 2;

      if (elapsed < totalSecs) {
        // round already started. wait to participate
        if (this.state.eventState === EventStates.waitPart && elapsed > 5) {
          return {
            remainSecs: totalSecs - elapsed,
            eventState: EventStates.waitPart,
            eventRound: i + 1,
          };
        }

        // start round left
        if (elapsed < roundInfo.duration) {
          return {
            remainSecs: roundInfo.duration - elapsed,
            eventState: EventStates.roundLeft,
            eventRound: i + 1,
          };
        }
        elapsed -= roundInfo.duration;

        // wait for round right
        if (elapsed < WAIT_SECS) {
          return {
            remainSecs: WAIT_SECS - elapsed,
            eventState: EventStates.roundWait,
            eventRound: i + 1,
          };
        }
        elapsed -= WAIT_SECS;

        // start round right
        if (elapsed < roundInfo.duration) {
          return {
            remainSecs: roundInfo.duration - elapsed,
            eventState: EventStates.roundRight,
            eventRound: i + 1,
          };
        }
        elapsed -= roundInfo.duration;

        // wait for next round
        if (elapsed < roundInfo.duration) {
          return {
            remainSecs: WAIT_SECS - elapsed,
            eventState: EventStates.roundVote,
            eventRound: i + 1,
          };
        }
        elapsed -= WAIT_SECS;
      } else {
        // elapsed round time. check next round
        elapsed -= totalSecs;
      }
    }

    // all the event rounds finished
    return {
      remainSecs: 0,
      eventState: EventStates.eventEnd,
      eventRound: roundCount,
    };
  }

  _startUpdateTimer() {
    this.timer = this.timer || setInterval(() => {
      this._updateState();
    }, 300);
  }
  _endUpdateTimer() {
    if (this.timer) {
      clearInterval(this.timer);
      this.tiemr = null;
    }
  }

  _updateState() {
    const state = this._getEventState();

    // changed event state. update ui
    if (this.state.eventState !== state.eventState) {
      if (!this.canVote && (state.eventState === EventStates.roundLeft || state.eventState === EventStates.roundRight)) {
        this.canVote = true;
      }

      console.log('updateState - ', state);

      const info: MDClash = gAppStates.clashContext.event;
      const roundInfo: MDClashRound = info.rounds[state.eventRound - 1];

      // if (this.state.eventState === EventStates.roundVote || this.state.eventState === EventStates.roundWait) {
      //   const params = {
      //     title: info.title,
      //   };
      //   if (this.roundWinner) {
      //     params.winner = this.roundWinner.userId;
      //     params.looser = this.roundLooser.userId;
      //   }
      //
      //   apis.endRound(info._id, params).then(() => {}).catch(() => {});
      // }
      if (this.state.eventState === EventStates.roundLeft || state.eventState === EventStates.roundRight) {
        const params = {
          title: info.title,
        };
        apis.endRound(info._id, params).then(() => {}).catch(() => {});
      }
      if (state.eventState === EventStates.roundLeft || state.eventState === EventStates.roundRight) {
        this.voteDialog.dismiss();

        this.roundWinner = null;
        this.roundLooser = null;
        const params = {
          title: info.title,
          duration: roundInfo.duration,
          description: roundInfo.description,
          // looser: roundInfo.looser,
          // winner: roundInfo.winner,
        };
        apis.startRound(info._id, params).then(() => {}).catch(() => {});
      }
      if (state.eventState === EventStates.roundVote || state.eventState === EventStates.roundWait) {
        this.voteDialog.show();
      }

      // finished event. clear timer
      if (state.eventState === EventStates.eventEnd) {
        this._endUpdateTimer();
        this.voteDialog.dismiss();
        this.finalPopup.show();
      }

      this.setState(state);
      return;
    }

    // update time
    if (this.state.remainSecs !== state.remainSecs) {
      this.setState(state);
    }
  }

  _loadComments() {
    const info = gAppStates.clashContext.event;
    const op1 = info.opponents[0] || {};
    const op2 = info.opponents[1] || {};

    apis.getComments({ clashId: info._id }).then((res) => {
      const comments = MDComment.parseList(_.map(res, value => value));
      const commentsLeft = _.filter(comments, { opponentId: op1.userId }) || [];
      const commentsRight = _.filter(comments, { opponentId: op2.userId }) || [];

      this._buildDataSource(commentsLeft, commentsRight);
      this.forceUpdate();
    }).catch((err) => {
      console.log('getComments failed - ', err);
    });
  }

  _formatTime(secs: Number): String {
    let minutes = parseInt(secs / 60, 10);
    const seconds = secs % 60;
    if (minutes >= 60) {
      const hours = parseInt(minutes / 60, 10);
      minutes %= 60;
      return `${hours}:${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
    }
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  }

  _onPressBack = () => {
    navHandler.navback(null, navkeys.clash);
  }

  _onKeyboardShow = (e) => {
    const height = e.endCoordinates.height - sizes.bottom.marginBottom;
    if (this.state.keyboardHeight === height) return;

    this.setState({ keyboardHeight: height });

    const anims = [];
    anims.push(Animated.timing(this.state.animSearchBottom, {
      toValue: this.state.keyboardHeight,
      duration: 300,
    }));

    if (this.txtSearchLeft && this.txtSearchLeft.isFocused()) {
      anims.push(Animated.timing(this.state.animSearchRightFlex, {
        toValue: 0,
        duration: 300,
      }));
    } else if (this.txtSearchRight && this.txtSearchRight.isFocused()) {
      anims.push(Animated.timing(this.state.animSearchLeftFlex, {
        toValue: 0,
        duration: 300,
      }));
    }
    Animated.parallel(anims).start();
  }
  _onKeyboardHide = () => {
    this.setState({ keyboardHeight: 0 });

    const anims = [];
    anims.push(Animated.timing(this.state.animSearchBottom, {
      toValue: this.state.keyboardHeight,
      duration: 300,
    }));
    anims.push(Animated.timing(this.state.animSearchRightFlex, {
      toValue: 1,
      duration: 300,
    }));
    anims.push(Animated.timing(this.state.animSearchLeftFlex, {
      toValue: 1,
      duration: 300,
    }));
    Animated.parallel(anims).start();
  }
  _onPressSearchOverlay = () => {
    Keyboard.dismiss();
  }
  _onPressSendComment = (left: Boolean) => {
    Keyboard.dismiss();

    const edit = left ? this.txtSearchLeft : this.txtSearchRight;
    if (edit) {
      edit.setNativeProps({ text: '' });
    }

    const comment = left ? this.state.commentLeft : this.state.commentRight;
    if (!comment || comment.length === 0) return;

    const info = gAppStates.clashContext.event;
    const op = (left ? info.opponents[0] : info.opponents[1]) || {};

    const params = {
      userId: gAppStates.user.userId,
      comment,
      clashId: info._id,
      opponentId: op.userId,
    };

    apis.createComment(params).then(() => {
      this._loadComments();
    }).catch(() => {
    });
  }
  _onPressVote = (left: Boolean) => {
    this.voteDialog.dismiss();

    const info = gAppStates.clashContext.event;
    const opWinner = (left ? info.opponents[0] : info.opponents[1]) || {};
    const opLooser = (left ? info.opponents[1] : info.opponents[0]) || {};
    if (left) {
      this.roundWinner = opWinner;
      this.roundLooser = opLooser;
    }

    // const params = {
    //   clashId: info._id,
    //   opponentId: op.userId,
    // };
    // apis.createForward(params);
  }

  _onMediaLoad = (params: Object, left: Boolean) => {
    console.log('onMediaLoad', params);
    if (left) {
      this.setState({ videoLeftReady: true });
      Animated.timing(this.state.animPlayerLeftOpacity, {
        toValue: 1,
        duration: 500,
      }).start();
    } else {
      this.setState({ videoRightReady: true });
      Animated.timing(this.state.animPlayerRightOpacity, {
        toValue: 1,
        duration: 500,
      }).start();
    }
  }
  _onMediaProgress = (params: Object, left: Boolean) => {
    left;
  }
  _onMediaEnd = (left: Boolean) => {
    console.log('onMediaEnd ', left ? 'left' : 'right');
    // if (left) {
    //   this.playerLeft && this.playerLeft.seek(0);
    // } else {
    //   this.playerRight && this.playerRight.seek(0);
    // }
  }

  _renderTitle = () => {
    const info = gAppStates.clashContext.event;
    const op1 = info.opponents[0] || {};
    const op2 = info.opponents[1] || {};

    return (<View style={styles.title_bar} >
      <View style={styles.view_title} >
        <Text style={styles.txt_title}>{ info.title }</Text>
        <View style={styles.view_title_names} >
          <Text style={styles.txt_title_names} >{ op1.username || '' }</Text>
          <View style={styles.view_title_vs} >
            <Text style={styles.txt_title_vs} >VS</Text>
          </View>
          <Text style={styles.txt_title_names} >{ op2.username || '' }</Text>
        </View>
      </View>
      <Button style={styles.btn_back} onPress={this._onPressBack} >
        <IOIcon name="ios-arrow-back" size={24} color="#4B4B4B" />
      </Button>
    </View>);
  }

  _renderRound = () => {
    const info = gAppStates.clashContext.event;
    const op1 = info.opponents[0] || {};
    const op2 = info.opponents[1] || {};

    return (<View style={styles.content}>
      {
        this.state.eventState === EventStates.waiting ?
          this._renderWait() :
          this._renderPlayers(op1, op2)
      }
      {
        this.state.eventState === EventStates.waiting ?
          null :
          this._renderRoundInfo(op1, op2)
      }
      { this._renderComments() }
    </View>);
  }

  _renderWait = () => (
    <View style={styles.view_wait} >
      <Text style={styles.txt_waiting} >WAITING FOR EVENT START</Text>
      <Text style={styles.txt_waiting_timer} ref={(node) => { this.lbWaitTimer = node; }}>
        {this._formatTime(this.state.remainSecs)}
      </Text>
    </View>
  )

  _renderPlayers = (op1: MDClashOpponent, op2: MDClashOpponent) => (
    <View style={styles.row_players}>
      { this._renderPlayer(op1, this.state.eventState === EventStates.roundLeft, true) }
      { this._renderPlayer(op2, this.state.eventState === EventStates.roundRight, false) }
    </View>
  )

  _renderPlayer = (op: MDClashOpponent, active: Boolean, left: Boolean) => (
    <View style={styles.view_player_container}>
      <Image source={{ uri: op.avatar }} style={styles.img_player_avatar} resizeMode="cover" />
      <Animated.View
        style={[
          styles.view_player_wrapper,
          { opacity: left ? this.state.animPlayerLeftOpacity : this.state.animPlayerRightOpacity },
        ]}
      >
        <Video
          ref={(node) => { if (left) { this.playerLeft = node; } else { this.playerRight = node; } }}
          key={op.streamUrl}
          source={{ uri: op.streamUrl }}
          repeat
          playInBackground={false}
          resizeMode="contain"
          muted={!active}
          style={styles.video_player}
          paused={false}
          onLoad={(params) => { this._onMediaLoad(params, left); }}
          onProgress={(params) => { this._onMediaProgress(params, left); }}
          onEnd={() => { this._onMediaEnd(left); }}
        />
      </Animated.View>
      { active ? <View style={styles.view_player_active} /> : null }
    </View>
  )

  _renderRoundInfo = (op1: MDClashOpponent, op2: MDClashOpponent) => (
    <View style={styles.row_round_info} >
      { this._renderPlayerInfo(op1) }
      { this._renderRoundTimer() }
      { this._renderPlayerInfo(op2) }
    </View>
  )
  _renderPlayerInfo = (op: MDClashOpponent) => (
    <View style={styles.row_round_player} >
      <View style={styles.view_info_name} >
        <Text style={styles.txt_info_name}>{ op.username || '' }</Text>
        <Text style={styles.txt_info_score}>{ op.score || '' }</Text>
      </View>
      <Text style={styles.txt_info_reviews}>238 Forwards • $0.43</Text>
    </View>
  )
  _renderRoundTimer = () => {
    const { eventState, eventRound, remainSecs } = this.state;
    const activeLeft: Boolean = eventState === EventStates.roundLeft;
    const activeRight: Boolean = eventState === EventStates.roundRight;
    let clrBack: String = 'red';
    let clrText: String = 'white';

    if (activeLeft || activeRight) {
      clrBack = '#1FC800';
      clrText = 'white';
    } else if (eventState === EventStates.roundWait) {
      clrBack = '#FFEE00';
      clrText = '#222';
    } else {
      clrBack = '#FF0000';
      clrText = 'white';
    }

    return (<View style={styles.row_round_timer} >
      <View style={[styles.view_round_timer, { backgroundColor: clrBack }]}>
        <Text style={[styles.txt_player_tick, { opacity: activeLeft ? 1 : 0 }]} >•</Text>
        <Text style={[styles.txt_info_time, { color: clrText }]}>{this._formatTime(remainSecs)}</Text>
        <Text style={[styles.txt_player_tick, { opacity: activeRight ? 1 : 0 }]} >•</Text>
      </View>
      <Text style={styles.txt_info_round}>{`ROUND ${eventRound}`}</Text>
    </View>);
  }

  _renderComments = () => (
    <View style={styles.view_comments} >
      { this._renderCommentList(this.state.dataSource1) }
      { this._renderCommentList(this.state.dataSource2) }
    </View>
  )
  _renderCommentList = (ds: ListView.DataSource) => (
    <ListView
      enableEmptySections
      style={styles.list_comment}
      dataSource={ds}
      renderRow={this._renderComment}
    />
  )
  _renderComment = (comment) => {
    const name = `${comment.user.FirstName} ${comment.user.LastName}`;
    const time = moment(comment.createdAt).format('h:mmA');
    return (
      <View style={styles.row_comment} >
        <View style={styles.view_comment_user} >
          <Text style={styles.txt_comment_user} >{name}</Text>
          <Text style={styles.txt_comment_time} >{` at ${time}`}</Text>
        </View>
        <Text style={styles.txt_comment_text} numberOfLines={0} >{comment.comment}</Text>
      </View>
    );
  }

  _renderSearchBar = () => {
    const info = gAppStates.clashContext.event;
    const op1 = info.opponents[0] || {};
    const op2 = info.opponents[1] || {};

    return (
      <Animated.View
        style={[
          styles.search_bar,
          { bottom: this.state.animSearchBottom },
          { transform: [{ translateY: -sizes.bottom.marginBottom }] },
        ]}
      >
        { this._renderPlayerSearch(op1, true, this.state.animSearchLeftFlex) }
        <View style={[styles.view_separator, { opacity: this.state.keyboardHeight === 0 ? 1 : 0 }]} />
        { this._renderPlayerSearch(op2, false, this.state.animSearchRightFlex) }
      </Animated.View>
    );
  }
  _renderSearchOverlay = () => {
    if (this.state.keyboardHeight === 0) return null;
    return (
      <Button style={styles.view_search_overlay} activeOpacity={1} onPress={this._onPressSearchOverlay} />
    );
  }

  _renderPlayerSearch = (op: MDClashOpponent, left: Boolean, flex: Animated.Value) => (
    <Animated.View style={[styles.view_search_bar, { flex }]} >
      <View style={styles.view_search_bar1} >
        { left || this.state.keyboardHeight !== 0 ? (
          <View style={[styles.view_search_sign, { borderRightWidth: 1 }]} >
            <Text style={styles.txt_search_sign} >$</Text>
          </View>
        ) : null }

        <View style={styles.view_search_input} >
          <TextInput
            ref={(node) => { if (left) { this.txtSearchLeft = node; } else { this.txtSearchRight = node; } }}
            style={styles.txt_search}
            placeholderTextColor="#999"
            placeholder={`Say something about ${op.username || ''}`}
            underlineColorAndroid="transparent"
            returnKeyType="send"
            onChangeText={(text) => { if (left) { this.state.commentLeft = text; } else { this.state.commentRight = text; } }}
            onSubmitEditing={() => { this._onPressSendComment(left); }}
          />
        </View>

        { left || this.state.keyboardHeight !== 0 ? null : (
          <View style={[styles.view_search_sign, { borderLeftWidth: 1 }]} >
            <Text style={styles.txt_search_sign} >$</Text>
          </View>
        )}
      </View>
    </Animated.View>
  )

  _renderPopupButton = (key, text, onPress, buttonStyle) => (
    <DialogButton
      key={key}
      text={text}
      onPress={onPress}
      buttonStyle={buttonStyle}
      textContainerStyle={{ paddingVertical: 12 }}
    />
  )

  _renderVoteDialog = () => {
    const info = gAppStates.clashContext.event;
    const op1 = info.opponents[0] || {};
    const op2 = info.opponents[1] || {};
    const action1 = this._renderPopupButton('btn-vote-1', op1.username || '', () => { this._onPressVote(true); }, {
      borderTopWidth: 1,
      borderBottomWidth: 1,
      borderColor: '#AAA',
      alignSelf: 'stretch',
    });
    const action2 = this._renderPopupButton('btn-vote-2', op2.username || '', () => { this._onPressVote(false); });
    const width = consts.phone ? sizes.screen.width - 32 * 2 : 450;
    const userName = this.state.eventState === EventStates.roundWait ? op1.username : op2.username;
    const nextName = this.state.eventState === EventStates.roundWait ? op2.username : op1.username;

    return (
      <PopupDialog
        ref={(node) => { this.voteDialog = node; }}
        actions={[action1, action2]}
        width={width}
        height={240}
      >
        <View style={styles.view_vote_content} >
          <Text style={styles.txt_vote}>{`Time's up for ${userName}. Next up is ${nextName}.\nWho won that round?`}</Text>
        </View>
      </PopupDialog>
    );
  }
  _renderFinalPopup = () => {
    const width = consts.phone ? sizes.screen.width - 32 * 2 : 450;
    const info = gAppStates.clashContext.event;
    const action1 = this._renderPopupButton('btn-final-1', 'OK', () => { this.finalPopup.dismiss(); }, {
      borderTopWidth: 1,
      borderColor: '#AAA',
      alignSelf: 'stretch',
    });
    return (
      <PopupDialog
        ref={(node) => { this.finalPopup = node; }}
        width={width}
        height={null}
        actions={[action1]}
      >
        <View style={styles.view_final_content} >
          <Text style={styles.txt_final} numberOfLines={0} >{`This Clash is over! And the winner is ${info.opponents[0].username}`}</Text>
        </View>
      </PopupDialog>
    );
  }

  render() {
    return (
      <View style={styles.container} >
        { this._renderTitle() }
        { this._renderRound() }
        { this._renderSearchBar() }
        { this._renderSearchOverlay() }
        { this._renderVoteDialog() }
        { this._renderFinalPopup() }
      </View>
    );
  }
}

const mapStateToProps = state => ({ // eslint-disable-line
});

const mapDispatchToProps = dispatch => ({ // eslint-disable-line
});

export default connect(mapStateToProps, mapDispatchToProps)(EventDetail);
