import ClashEvents from './Events';
import ClashEventDetail from './EventDetail';

export {
  ClashEvents,
  ClashEventDetail,
};
