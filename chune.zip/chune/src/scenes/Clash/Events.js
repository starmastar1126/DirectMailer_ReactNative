import React, { Component } from 'react';
import { View, ListView, Text, Image, TextInput } from 'react-native';
import { Button } from '@components/button';
import { IOIcon } from '@components/icons';
import moment from 'moment';
import * as AddCalendarEvent from 'react-native-add-calendar-event';
import { connect } from 'react-redux';
import { gAppStates } from '@common';
import { apis } from '@lib';
import g from '@global';
// import { DateUtil } from '@utils';
import { MDClash, MDJudge } from '@model';
import { handler, navkeys } from '@redux';
import styles from './Events.styles';

const { navigation: navHandler } = handler;

class Events extends Component {
  timer: * = null;

  constructor(props) {
    super(props);

    this.state = {
      dataSource: null,
    };

    this.ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
    this._buildDataSource([]);
  }

  componentDidMount() {
    this._loadEvents();
    this._loadJudge();
    this._startUpdateTimer();
  }

  _buildDataSource(events: Array<Object>) {
    this.state.dataSource = this.ds.cloneWithRows(events);
  }

  _startUpdateTimer() {
    this.timer = this.timer || setInterval(() => {
      this.forceUpdate();
    }, 300);
  }
  _endUpdateTimer() {
    if (this.timer) {
      clearInterval(this.timer);
      this.tiemr = null;
    }
  }

  _loadEvents() {
    apis.getClashes().then((infos) => {
      const events = MDClash.parseList(infos);

      // let curDate = new Date();
      // curDate.setHours(curDate.getHours() + 2);
      // curDate.setMinutes(0);
      // curDate.setSeconds(0);
      // events[0].startDate = curDate;
      // curDate = new Date();
      // curDate.setMinutes(curDate.getMinutes() + 2);
      // curDate.setSeconds(0);
      // events[1].startDate = curDate;

      this._buildDataSource(events);
      this.forceUpdate();
    }).catch((e) => {
      console.log('_loadEvents failed - ', e);
    });
  }

  _loadJudge() {
    apis.isJudge(gAppStates.user.userId).then(() => {
      this.forceUpdate();
    }).catch(() => {});
  }

  _onPressEvent = (info) => {
    // gAppStates.clashContext.event = info;
    // navHandler.navigate({ routeName: 'clashEventDetail' });

    if (gAppStates.user.loggedIn) {
      gAppStates.clashContext.event = info;
      navHandler.navigate({ routeName: 'eventDetail' }, navkeys.clash);
      // navHandler.navigate({ routeName: 'jerkVote' }, navkeys.clash);
    } else {
      navHandler.navigate({ routeName: 'signIn' });
    }
  }
  _onPressEventAdd = (clash: MDClash) => {
    const op1: Object = clash.opponents[0] || {};
    const op2: Object = clash.opponents[1] || {};
    const startDate = moment(clash.startDate);
    const endDate = moment(clash.startDate);

    clash.rounds.forEach((round) => {
      endDate.add(round.duration * 2 + 60, 'seconds');
    });

    const eventConfig = {
      title: 'CHUNE EVENT',
      notes: `${clash.title}\n${op1.username || ''} vs ${op2.username || ''}`,
      startDate: startDate.format('YYYY-MM-DDTHH:mm:ss.SSSZZ'),
      endDate: endDate.format('YYYY-MM-DDTHH:mm:ss.SSSZZ'),
    };
    AddCalendarEvent.presentNewCalendarEventDialog(eventConfig).then((eventId) => {
      // handle success (receives event id) or dismissing the modal (receives false)
      if (eventId) {
        console.log('Calendar Added: ', eventId);
      } else {
        console.log('Calendar Add Cancelled');
      }
    }).catch((error: string) => {
      // handle error such as when user rejected permissions
      console.log('Add Calendar failed: ', error);
    });
  }

  _onPressJudge = () => {
    navHandler.navigate({ routeName: 'jerkVote' }, navkeys.clash);
  }

  _renderSearchBar = () => {
    const iconSize = 20;
    return (
      <View style={styles.search_bar} >
        <IOIcon name="ios-search-outline" size={iconSize} color="#222" style={styles.img_search} />
        <TextInput
          ref={(node) => { this.editSearch = node; }}
          style={styles.search_edit}
          placeholderTextColor="#898989"
          placeholder="SEARCH"
          underlineColorAndroid="transparent"
        />
      </View>
    );
  }

  _renderJudge = () => {
    const judge: MDJudge = gAppStates.judge;
    if (judge.judgeQty <= 0) return null;

    let message = 'VOTE FOR JERK WINNER!';
    if (judge.hasVoted) message = 'VIEW WINNER!';

    return (
      <Button style={styles.btn_judge} onPress={this._onPressJudge} >
        <Text style={styles.txt_judge1} >YOUR A JUDGE</Text>
        <Text style={styles.txt_judge2} >{message}</Text>
      </Button>
    );
  }

  _renderRow = (info: MDClash) => {
    const op1: Object = info.opponents[0] || {};
    const op2: Object = info.opponents[1] || {};
    const startDate: Date = info.startDate; // DateUtil.toUTC(info.startDate);
    const curDate: Date = new Date();

    const remain: Number = parseInt((startDate.getTime() - curDate.getTime()) / 1000, 10);
    let remain1 = remain;
    const days: Number = parseInt(remain1 / (3600 * 24), 10);
    remain1 -= days * 3600 * 24;
    const hours: Number = parseInt(remain1 / 3600, 10);
    remain1 -= hours * 3600;
    const minutes: Number = parseInt(remain1 / 60, 10);
    remain1 -= minutes * 60;
    const seconds: Number = remain1;
    let timeDesc: String = '';
    if (days > 0) {
      timeDesc = g.formatCount(days, ' day');
    } else if (hours > 0) {
      timeDesc = g.formatCount(hours, ' hour');
    } else if (minutes > 0) {
      timeDesc = g.formatCount(minutes, ' min');
    } else {
      timeDesc = g.formatCount(seconds, ' sec');
    }

    return (<Button style={styles.row} onPress={() => { this._onPressEvent(info); }} >
      <View style={styles.row_view_infos} >
        <View style={styles.row_view_left} >
          <Button style={styles.btn_row_plus} onPress={() => { this._onPressEventAdd(info); }}>
            <IOIcon name="md-add" size={20} color="#222" />
          </Button>
        </View>

        <View style={styles.row_view_mid} >
          <View style={styles.row_view_info}>
            <Text style={styles.txt_row_title} >{ info.title }</Text>

            <View style={styles.row_view_names} >
              <Text style={styles.txt_row_name} >{ op1.username || '' }</Text>
              <View style={styles.row_view_vs} >
                <Text style={styles.txt_row_vs} >VS</Text>
              </View>
              <Text style={styles.txt_row_name} >{ op2.username || '' }</Text>
            </View>

            <View style={styles.row_view_scores} >
              <Text style={styles.txt_row_score}>{ op1.score || ''}</Text>
              <Text style={styles.txt_row_score}>{ op2.score || ''}</Text>
            </View>
          </View>
        </View>

        <View style={styles.row_view_right} >
          {
            remain > 0 ? (
              <View style={styles.row_view_date} >
                <Text style={styles.txt_row_date_start} >CLASH STARTS IN</Text>
                <Text style={styles.txt_row_time} >{ timeDesc }</Text>
              </View>
            ) : (
              <View style={styles.row_view_date} >
                <Text style={styles.txt_row_live} >LIVE NOW</Text>
              </View>
            )
          }
        </View>
      </View>
      <View style={styles.row_view_avatar} >
        <Image source={{ uri: op1.avatar }} style={styles.img_row_avatar} resizeMode="cover" />
        <Image source={{ uri: op2.avatar }} style={styles.img_row_avatar} resizeMode="cover" />
      </View>
    </Button>);
  }

  _renderList = () => (
    <View style={styles.content} >
      <ListView
        enableEmptySections
        style={styles.list}
        dataSource={this.state.dataSource}
        renderRow={this._renderRow}
      />
    </View>
  )

  render() {
    return (
      <View style={styles.container} >
        { this._renderSearchBar() }
        { this._renderJudge() }
        { this._renderList() }
      </View>
    );
  }
}

const mapStateToProps = state => ({
  loggedIn: state.main.user.loggedIn,
  judgeFlag: state.main.judgeFlag,
});

const mapDispatchToProps = dispatch => ({ // eslint-disable-line
});

export default connect(mapStateToProps, mapDispatchToProps)(Events);
