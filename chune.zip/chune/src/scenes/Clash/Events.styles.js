import { StyleSheet } from 'react-native';
import { basestyles as bs, sizes } from '@theme';

const avatarWidth = sizes.screen.width / 2 - 0.5;
const avatarHeight = avatarWidth * 0.8;

export default StyleSheet.create({
  container: {
    ...bs.layout.match_parent,
    ...bs.align.start_center,
    backgroundColor: 'white',
  },
  content: {
    ...bs.layout.match_parent,
    ...bs.align.start_center,
    marginBottom: sizes.bottom.marginBottom,
    backgroundColor: 'transparent',
  },

  // search bar
  search_bar: {
    ...bs.align.start_center,
    ...bs.align.self.stretch,
    ...bs.layout.row,
    ...bs.statusbar.padding,
    height: 40 + sizes.statusBarHeight,
    backgroundColor: 'transparent',
  },
  search_edit: {
    ...bs.layout.match_parent,
    ...bs.font.normal,
    color: '#222',
    fontSize: 12,
  },
  img_search: {
    paddingLeft: 8,
    paddingRight: 8,
  },

  // judge
  btn_judge: {
    ...bs.align.self.stretch,
    ...bs.align.center,
    ...bs.pv_xls,
    backgroundColor: '#F8EC07',
  },
  txt_judge1: {
    ...bs.font.normal,
    fontSize: 12,
    color: '#000',
  },
  txt_judge2: {
    ...bs.font.semibold,
    fontSize: 20,
    color: '#000',
  },

  // listview
  list: {
    ...bs.layout.match_parent,
  },
  row: {
    ...bs.layout.match_parent,
    marginBottom: 8,
  },
  row_view_infos: {
    ...bs.layout.row,
    paddingLeft: 8,
    paddingRight: 8,
  },
  row_view_left: {
    ...bs.align.center_start,
    ...bs.mr_xs,
  },
  row_view_mid: {
    ...bs.align.center,
    flex: 2,
  },
  row_view_right: {
    ...bs.align.center_end,
    flex: 1,
  },
  btn_row_plus: {
    padding: 8,
  },
  row_view_info: {
    ...bs.layout.match_parent,
    ...bs.align.center,
  },
  txt_row_title: {
    ...bs.font.semibold,
    fontSize: 15,
    color: '#898989',
  },
  txt_row_name: {
    ...bs.font.normal,
    fontSize: 14,
    color: '#4B4B4B',
  },
  row_view_names: {
    ...bs.layout.row,
    ...bs.align.center,
    ...bs.align.self.stretch,
  },
  row_view_vs: {
    ...bs.align.center,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: 'red',
    marginLeft: 4,
    marginRight: 4,
  },
  txt_row_vs: {
    ...bs.font.normal,
    fontSize: 10,
    color: 'white',
    backgroundColor: 'transparent',
  },
  row_view_scores: {
    ...bs.layout.row,
  },
  txt_row_score: {
    ...bs.font.normal,
    flex: 1,
    fontSize: 11,
    color: 'rgba(75,75,75,0.5)',
    textAlign: 'center',
  },
  row_view_date: {
    ...bs.align.center,
  },
  txt_row_date_start: {
    ...bs.font.normal,
    fontSize: 12,
    color: '#898989',
  },
  txt_row_live: {
    ...bs.font.normal,
    fontSize: 14,
    color: '#898989',
  },
  txt_row_time: {
    ...bs.font.semibold,
    fontSize: 18,
    color: '#898989',
  },
  row_view_avatar: {
    ...bs.layout.row,
    ...bs.align.between_center,
  },
  img_row_avatar: {
    width: avatarWidth,
    height: avatarHeight,
  },
});
