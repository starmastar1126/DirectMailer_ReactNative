import { StyleSheet } from 'react-native';
import { basestyles as bs, sizes } from '@theme';

const avatarWidth = sizes.screen.width / 2 - 0.5;
const avatarHeight = sizes.screen.height * 0.4;

export default StyleSheet.create({
  container: {
    ...bs.layout.match_parent,
    ...bs.align.start_center,
    backgroundColor: 'white',
  },
  content: {
    ...bs.layout.match_parent,
    ...bs.align.start_center,
    marginBottom: sizes.bottom.marginBottom,
    backgroundColor: 'transparent',
  },

  // title
  title_bar: {
    ...bs.align.center,
    ...bs.align.self.stretch,
    ...bs.statusbar.padding,
    backgroundColor: 'white',
  },
  view_title: {
    ...bs.align.center,
    ...bs.align.self.stretch,
    marginTop: 6,
    marginBottom: 6,
  },
  txt_title: {
    ...bs.font.semibold,
    fontSize: 15,
    color: '#4B4B4B',
  },
  view_title_names: {
    ...bs.layout.row,
    ...bs.align.center,
    ...bs.align.self.stretch,
  },
  view_title_vs: {
    ...bs.align.center,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: 'red',
    marginLeft: 4,
    marginRight: 4,
  },
  txt_title_vs: {
    ...bs.font.normal,
    fontSize: 10,
    color: 'white',
    backgroundColor: 'transparent',
  },
  txt_title_names: {
    ...bs.font.normal,
    fontSize: 12,
    color: '#4B4B4B',
  },
  btn_back: {
    ...bs.layout.absolute,
    ...bs.align.center,
    left: 10,
    bottom: 0,
    top: sizes.statusBarHeight,
    paddingLeft: 8,
    paddingRight: 8,
  },

  // infos
  row_players: {
    ...bs.layout.row,
    ...bs.align.between_center,
    ...bs.align.self.stretch,
    backgroundColor: 'white',
  },
  view_player_container: {
    ...bs.align.start_center,
    width: avatarWidth,
    backgroundColor: 'black',
  },
  view_player_active: {
    ...bs.layout.absolute_full,
    borderColor: '#63B607',
    borderWidth: 1.5,
  },
  view_player_wrapper: {
    ...bs.layout.absolute_full,
    backgroundColor: 'black',
  },
  video_player: {
    ...bs.layout.match_parent,
  },
  img_player_avatar: {
    width: avatarWidth,
    height: avatarHeight,
  },

  // round info
  row_round_info: {
    ...bs.layout.row,
  },

  // round timer
  row_round_timer: {
    ...bs.align.center,
  },
  view_round_timer: {
    ...bs.layout.row,
    ...bs.align.center,
    backgroundColor: '#1FC800',
  },
  txt_info_time: {
    ...bs.font.semibold,
    fontSize: 14,
    color: 'white',
  },
  txt_player_tick: {
    ...bs.font.bold,
    fontSize: 14,
    color: 'white',
    marginLeft: 6,
    marginRight: 6,
  },
  txt_info_round: {
    ...bs.font.normal,
    fontSize: 11,
    color: '#4B4B4B',
  },

  // player info
  row_round_player: {
    ...bs.align.center,
    flex: 1,
  },
  view_info_name: {
    ...bs.layout.row,
    ...bs.align.center,
  },
  txt_info_name: {
    ...bs.font.normal,
    fontSize: 12,
    color: '#4B4B4B',
    marginRight: 5,
  },
  txt_info_score: {
    ...bs.font.normal,
    fontSize: 10,
    color: 'rgba(75,75,75,0.5)',
  },
  txt_info_reviews: {
    ...bs.font.normal,
    fontSize: 10,
    color: '#4B4B4B',
  },

  // comment
  view_comments: {
    ...bs.layout.row,
    ...bs.layout.match_parent,
    ...bs.mt_xs,
    marginBottom: sizes.bottom.searchHeight,
  },
  list_comment: {
    ...bs.layout.match_parent,
  },
  row_comment: {
    ...bs.layout.match_parent,
    ...bs.m_xls,
    ...bs.mh_sm,
  },
  view_comment_user: {
    ...bs.layout.row,
    ...bs.align.start_center,
  },
  txt_comment_user: {
    ...bs.font.semibold,
    fontSize: 10,
    color: '#4B4B4B',
  },
  txt_comment_time: {
    ...bs.font.normal,
    fontSize: 9,
    color: '#ACACAC',
  },
  txt_comment_text: {
    ...bs.layout.match_parent,
    ...bs.font.normal,
    fontSize: 11,
    color: '#707070',
  },

  // search bar
  search_bar: {
    ...bs.layout.absolute,
    ...bs.layout.row,
    ...bs.align.start_center,
    ...bs.align.self.stretch,
    left: 0,
    right: 0,
    height: sizes.bottom.searchHeight, // sizes.search.barHeight,
    backgroundColor: '#F4F4F4',
  },
  view_search_bar: {
    ...bs.align.self.stretch,
    overflow: 'hidden',
  },
  view_search_bar1: {
    ...bs.layout.absolute_full,
    ...bs.layout.row,
  },
  view_search_sign: {
    ...bs.align.center,
    ...bs.align.self.stretch,
    paddingLeft: 6,
    paddingRight: 6,
    borderColor: '#E4E4E4',
  },
  txt_search_sign: {
    ...bs.font.normal,
    fontSize: 13,
    color: '#999',
  },
  view_search_input: {
    ...bs.layout.match_parent,
  },
  txt_search: {
    ...bs.layout.match_parent,
    ...bs.font.normal,
    color: '#222',
    fontSize: 11,
    marginLeft: 5,
    marginRight: 5,
  },
  view_separator: {
    ...bs.align.self.stretch,
    width: 1,
    backgroundColor: '#E4E4E4',
  },
  view_search_overlay: {
    ...bs.layout.absolute_full,
    backgroundColor: 'transparent',
  },

  // waiting
  view_wait: {
    ...bs.align.center,
    ...bs.align.self.stretch,
    height: avatarHeight,
    backgroundColor: '#000',
  },
  txt_waiting: {
    ...bs.font.semibold,
    fontSize: 18,
    color: 'white',
  },
  txt_waiting_timer: {
    ...bs.font.bold,
    fontSize: 30,
    color: '#CCC',
  },

  // voteDialog
  view_vote_content: {
    ...bs.layout.match_parent,
    ...bs.align.center,
  },
  txt_vote: {
    ...bs.font.normal,
    fontSize: 15,
    color: 'black',
    textAlign: 'center',
  },

  // final popup
  view_final_content: {
    ...bs.align.center,
    ...bs.p_md,
  },
  txt_final: {
    ...bs.font.normal,
    fontSize: 16,
    color: 'black',
    textAlign: 'center',
  },
});
