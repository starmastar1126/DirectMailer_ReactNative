export const routeConfigs = {};
