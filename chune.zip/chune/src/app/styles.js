import { basestyles as bs } from '@theme';

export default {
  container: {
    ...bs.layout.match_parent,
  },
};
