var store;

export function setStore(newStore) {
  store = newStore;
}

export function getStore() {
  return store;
}
