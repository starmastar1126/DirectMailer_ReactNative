import React, { Component } from 'react';
import { View, Animated, PanResponder } from 'react-native';
import clamp from 'clamp';
import styles from './styles';

const SWIPE_THRESHOLD = 150;

export default class TinderCard extends Component {
  static propTypes = {
    ...View.propTypes,
    cards: React.PropTypes.array,
    cardIndex: React.PropTypes.number,
    cardStyle: React.PropTypes.any,
    renderBack: React.PropTypes.func,
    renderCard: React.PropTypes.func,
    onDragStart: React.PropTypes.func,
    onDragRelease: React.PropTypes.func,
  };
  static defaultProps = {
    ...View.defaultProps,
    renderBack: () => null,
    renderCard: () => (<View />),
    onDragStart: () => {},
    onDragRelease: () => {},
    cards: [],
    cardIndex: 0,
    cardStyle: styles.card,
  };

  constructor(props) {
    super(props);

    this.state = {
      pan: new Animated.ValueXY(0),
      enter: new Animated.Value(1.0),
      selected: this.props.cardIndex,
    };

    this.lastX = 0;
    this.lastY = 0;
    this.cardAnimation = null;

    this._createPanResponder();
  }

  // componentWillReceiveProps(nextProps) {
  //   if (this.props.cards !== nextProps.cards) {
  //     this.state.selected = nextProps.cardIndex;
  //   }
  // }

  _createPanResponder = () => {
    this._panResponder = PanResponder.create({
      // onStartShouldSetPanResponderCapture: (e, gestureState) => {
      //   this.props.onDragStart();
      //   this.lastX = gestureState.moveX;
      //   this.lastY = gestureState.moveY;
      //   return true;
      // },
      onMoveShouldSetPanResponderCapture: (e, gestureState) => {
        // if ((gestureState.dx === 0) && (gestureState.dy === 0)) return false;
        // if (!(Math.abs(this.lastX - gestureState.moveX) > 5 || Math.abs(this.lastY - gestureState.moveY) > 5)) return false;
        this.props.onDragStart();
        this.lastX = gestureState.moveX;
        this.lastY = gestureState.moveY;
        return true;
      },
      onPanResponderGrant: () => {
        this.state.pan.setOffset({ x: this.state.pan.x._value, y: this.state.pan.y._value });
        this.state.pan.setValue({ x: 0, y: 0 });
      },
      onPanResponderTerminationRequest: () => false,
      onPanResponderMove: Animated.event([
        null, { dx: this.state.pan.x, dy: this.state.pan.y },
      ]),
      onPanResponderTerminate: () => {
        this.props.onDragRelease();
        this._resetPan();
      },
      onPanResponderRelease: (e, { vx, vy, dy }) => {
        this.props.onDragRelease();
        this.state.pan.flattenOffset();
        let velocity;

        if (vy > 0) {
          velocity = clamp(vy, 3, 5);
        } else if (vy < 0) {
          velocity = clamp(vy * -1, 3, 5) * -1;
        } else {
          velocity = dy < 0 ? -3 : 3;
        }

        let hasSwipedVertically = Math.abs(this.state.pan.y._value) > SWIPE_THRESHOLD;
        if (hasSwipedVertically === false && Math.abs(vy) > 1) {
          hasSwipedVertically = true;
        }
        const hasMovedUp = hasSwipedVertically && this.state.pan.y._value < 0;
        let cancelled = true;
        if (hasSwipedVertically) {
          cancelled = false;

          if (hasMovedUp && this.state.selected === 0) {
            cancelled = true;
          } else if (!hasMovedUp && this.state.selected >= this.props.cards.length - 1) {
            cancelled = true;
          }
        }

        if (cancelled) {
          this._resetPan();
          return;
        }

        this.cardAnimation = Animated.decay(this.state.pan, {
          velocity: { x: vx, y: velocity },
          deceleration: 0.987,
        });
        this.cardAnimation.start((status) => {
          if (status.finished) {
            if (hasMovedUp) {
              this._gotoPrevCard();
            } else {
              this._gotoNextCard();
            }
          } else {
            this._resetState();
          }

          this.cardAnimation = null;
        });
      },
    });
  }

  _resetPan() {
    Animated.spring(this.state.pan, {
      toValue: { x: 0, y: 0 },
      friction: 4,
    }).start();
  }

  _resetState() {
    this.state.pan.setValue({ x: 0, y: 0 });
    this.state.enter.setValue(0);
    this._animateEntrance();
  }

  _animateEntrance() {
    Animated.spring(
      this.state.enter,
      { toValue: 1, friction: 8 },
    ).start();
  }

  _gotoNextCard() {
    this._resetState();
    let newSelected = this.state.selected;
    if (this.state.selected < this.props.cards.length - 1) {
      newSelected = this.state.selected + 1;
    }
    console.log(newSelected);
    this.setState({ selected: newSelected });
  }

  _gotoPrevCard() {
    this._resetState();
    let newSelected = this.state.selected;
    if (this.state.selected > 0) {
      newSelected = this.state.selected - 1;
    }
    console.log(newSelected);
    this.setState({ selected: newSelected });
  }

  renderCard = () => {
    const { pan, enter } = this.state;
    const [translateX, translateY] = [pan.x, pan.y];
    const card = this.props.cards[this.state.selected];
    // const rotate = pan.x.interpolate({ inputRange: [-200, 0, 200], outputRange: ["-30deg", "0deg", "30deg"] });
    // const opacity = pan.x.interpolate({ inputRange: [-200, 0, 200], outputRange: [0.5, 1, 0.5] });

    const scale = enter;

    const animatedCardStyles = { transform: [{ translateX }, { translateY }/* , { rotate }*/, { scale }]/* , opacity*/ };

    return (
      <Animated.View key="top" style={[this.props.cardStyle, animatedCardStyles]} {... this._panResponder.panHandlers} >
        {this.props.renderCard(card)}
      </Animated.View>
    );
  }

  render() {
    const { renderBack, ...otherProps } = this.props;

    return (
      <View {...otherProps} >
        {renderBack()}
        {this.renderCard()}
      </View>
    );
  }
}
