import { StyleSheet } from 'react-native';
import { basestyles as bs } from '@theme';

export default StyleSheet.create({
  back: {
    ...bs.layout.absolute_full,
    backgroundColor: 'black',
  },
  card: {
    ...bs.layout.match_parent,
  },
});
