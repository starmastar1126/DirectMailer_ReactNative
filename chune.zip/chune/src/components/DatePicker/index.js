import DateRangePicker from './src';

export default DateRangePicker;
