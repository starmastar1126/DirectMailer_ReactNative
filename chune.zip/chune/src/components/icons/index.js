import SLIcon from 'react-native-vector-icons/SimpleLineIcons';
import FAIcon from 'react-native-vector-icons/FontAwesome';
import FDIcon from 'react-native-vector-icons/Foundation';
import IOIcon from 'react-native-vector-icons/Ionicons';
import ETIcon from 'react-native-vector-icons/Entypo';
import MCIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import MTIcon from 'react-native-vector-icons/MaterialIcons';
import OTIcon from 'react-native-vector-icons/Octicons';
import ZCIcon from 'react-native-vector-icons/Zocial';

export {
  SLIcon,
  FAIcon,
  FDIcon,
  IOIcon,
  ETIcon,
  MCIcon,
  MTIcon,
  OTIcon,
  ZCIcon,
};
