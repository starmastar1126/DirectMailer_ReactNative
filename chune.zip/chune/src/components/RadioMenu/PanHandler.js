import { PanResponder, findNodeHandle } from 'react-native';

const UIManager = require('NativeModules').UIManager;

export default class PanHandler {

  constructor(parent) {
    this.parent = parent;
    this.moving = false;
    this.frameInited = false;
    this.frameIniting = false;
    this.frame = {};

    this.panResponder = PanResponder.create({
      onMoveShouldSetResponderCapture: this.onMoveShouldSetResponderCapture,
      onMoveShouldSetPanResponderCapture: this.onMoveShouldSetPanResponderCapture,
      onPanResponderGrant: this.onPanResponderGrant,
      onPanResponderMove: this.onPanResponderMove,
      onPanResponderRelease: this.onPanResponderRelease,
      onPanResponderTerminate: this.onPanResponderRelease,
    });
  }

  // want to allow MOVEMENT of the view weâ€™ll attach this panresponder to.
  onMoveShouldSetResponderCapture = () => true;

  // want to allow DRAGGING of the view weâ€™ll attach this panresponder to.
  onMoveShouldSetPanResponderCapture = (event, gs) => {
    if (this.frameInited === false) {
      if (this.frameIniting === false) {
        this.frameIniting = true;

        const handle = findNodeHandle(this.parent);
        UIManager.measure(handle, (frameX, frameY, frameWidth, frameHeight, pageX, pageY) => {
          this.frame = { x: frameX, y: frameY, pageX, pageY, width: frameWidth, height: frameHeight };
          this.frameIniting = false;
          this.frameInited = true;
        });
      }
      return false;
    }
    if (this.isInsideRing(gs)) {
      console.log('start tracking rotation handler');
      this.moving = true;
      return true;
    }
    this.moving = false;
    return true;
  }

  // invoked when we got ACCESS to the movement of the element
  onPanResponderGrant = (event, gs) => {
    if (this.moving) {
      const gsAngle = this.rotationForLocation(gs.moveX, gs.moveY);
      this.gsStartAngle = gsAngle;
      this.viewStartAngle = this.parent.state.animRotate.__getValue();
    }
  }

  // invoked when we MOVE the element, which we can use to calculate the next value for the object
  onPanResponderMove = (event, gs) => {
    if (this.moving) {
      const gsAngle = this.rotationForLocation(gs.moveX, gs.moveY);
      const delta = gsAngle - this.gsStartAngle;
      const newAngle = (this.viewStartAngle + delta + 720) % 360;
      this.parent._didRotateMove(newAngle);
    }
  }

  // invoked when we RELEASE the view
  onPanResponderRelease = (event, gs) => {
    if (this.moving) {
      const gsAngle = this.rotationForLocation(gs.moveX, gs.moveY);
      const gsAngleV = this.rotationForLocation(gs.moveX + gs.vx, gs.moveY + gs.vy);
      const delta = gsAngle - this.gsStartAngle;
      const newAngle = (this.viewStartAngle + delta + 720) % 360;
      this.parent._didRotateRelease(newAngle, gsAngleV - gsAngle);
    }
    this.moving = false;
    this.frameInited = false;
  }

  isInsideRing(gs) {
    const frame = this.frame;
    const outerRadius = frame.width / 2;
    const innerRadius = outerRadius - this.parent.props.itemSize;
    const offsetX = gs.moveX - (frame.pageX + frame.width / 2);
    const offsetY = gs.moveY - (frame.pageY + frame.height / 2);
    // const dist = Math.sqrt((offsetX ** 2) + (offsetY ** 2));
    const dist = Math.sqrt(offsetX * offsetX + offsetY * offsetY);
    return dist <= outerRadius && dist >= innerRadius;
  }

  rotationForLocation(x, y) {
    const frame = this.frame;
    const offsetX = x - (frame.pageX + frame.width / 2);
    const offsetY = y - (frame.pageY + frame.height / 2);
    const rad = Math.atan2(offsetY, offsetX);
    const deg = (rad / Math.PI * 180) + (rad > 0 ? 0 : 360);

    return deg;
  }
}
