/* eslint-disable no-use-before-define */
import React, { Component } from 'react';
import { View, StyleSheet, Animated } from 'react-native';
import { global as g } from '@common';
import { basestyles as bs, images } from '@theme';
// import Button from '../Button';
import PanHandler from './PanHandler';

export default class RadioMenu extends Component {
  static propTypes = {
    ...View.propTypes,
    items: React.PropTypes.array,
    itemSize: React.PropTypes.number,
    renderItem: React.PropTypes.func,
    onSelectItem: React.PropTypes.func,
  };

  static defaultProps = {
    items: [],
    itemSize: 60,
    renderItem: () => null,
    onSelectItem: () => {},
  };

  constructor(props) {
    super(props);

    this.state = {
      animRotate: new Animated.Value(0),
      selectedItem: 0,
      selectedIndex: 0,
      frame: { width: 1, height: 1 },
    };
    this.panHandler = new PanHandler(this);
    this.state.animRotate.addListener(this._onRotate);
  }

  _onLayout = (event) => {
    const newFrame = event.nativeEvent.layout;
    const curFrame = this.state.frame;
    if (!g.isEqualFrame(curFrame, newFrame)) {
      this.setState({ frame: newFrame });
    }
  }

  selectItem(itemIndex) {
    const cellAngle = this.cellAngle;
    const itemCount = this.itemCount;
    const cellCount = this.cellCount;
    const needForward = (itemIndex + itemCount - this.state.selectedItem) % itemCount;
    if (needForward === 0) return;

    if (needForward < cellCount / 2) {
      const newIndex = (this.state.selectedIndex + needForward) % cellCount;
      const newRotate = (720 - newIndex * cellAngle) % 360;
      this.state.animRotate.setValue(newRotate);
    } else {
      const needBackward = (this.state.selectedItem + itemCount - itemIndex) % itemCount;
      const newIndex = (this.state.selectedIndex + cellCount - needBackward) % cellCount;
      const newRotate = (720 - newIndex * cellAngle) % 360;
      this.state.animRotate.setValue(newRotate);
    }
  }

  selectIndex(index, animated) {
    if (this.state.index === index) return;
  }

  get itemCount() {
    return this.props.items.length;
  }
  get cellCount() {
    return Math.floor(this.itemCount / 2) * 4 + 2;
  }
  get cellAngle() {
    return 360 / this.cellCount;
  }
  get selectedItem() {
    return this.state.selectedItem;
  }

  _itemForIndex = (index, baseIndex, baseItem) => {
    const itemCount = this.itemCount;
    const cellCount = this.cellCount;
    const listIndex = Math.floor(index + cellCount - baseIndex) % cellCount;
    if (listIndex < cellCount / 2) {
      return Math.floor(baseItem + listIndex) % itemCount;
    }
    return Math.floor(baseItem + itemCount - (cellCount - listIndex)) % itemCount;
  }

  _didRotateMove = (angle) => {
    this.state.animRotate.setValue(angle);
  }

  _didRotateRelease = (ang1, va) => {
    const cellAngle = this.cellAngle;
    const addAngle = va * 50;
    const oldAngle = this.state.animRotate.__getValue();
    const newAngle = Math.floor((oldAngle + addAngle + cellAngle / 2) / cellAngle) * cellAngle;
    Animated.spring(this.state.animRotate, {
      duration: 500,
      toValue: newAngle,
    }).start();
  }

  _onRotate = ({ value }) => {console.log(value);
    const cellAngle = this.cellAngle;
    const angle = (720 - value) % 360;
    const oldSelectedIndex = this.state.selectedIndex;
    const newSelectedIndex = Math.floor(((angle + cellAngle / 2) % 360) / cellAngle);
    const newSelectedItem = this._itemForIndex(newSelectedIndex, oldSelectedIndex, this.state.selectedItem);
    if (newSelectedIndex !== this.state.selectedIndex) {
      this.setState({
        selectedIndex: newSelectedIndex,
        selectedItem: newSelectedItem,
      });
      this.props.onSelectItem(newSelectedItem);
    }
  }

  _renderCellContent(itemIndex, index) {
    if (this.props.items.length <= 0) return null;
    const selected = this.state.selectedIndex === index;
    return this.props.renderItem(this.props.items[itemIndex], itemIndex, selected);
  }

  _renderCell(index) {
    const { itemSize } = this.props;
    const cellAngle = this.cellAngle;
    const iangle = index * cellAngle;
    const itemIndex = this._itemForIndex(index, this.state.selectedIndex, this.state.selectedItem);
    const frame = this.state.frame;

    return (
      <Animated.View
        key={`cell_${index}`}
        style={[
          bs.align.center,
          { position: 'absolute' },
          { left: (frame.width - itemSize) / 2, top: (frame.height - itemSize) / 2 },
          { width: itemSize, height: itemSize },
          { transform: [{ rotate: `${iangle}deg` }] },
        ]}
      >
        <View
          style={[
            bs.align.center,
            { width: itemSize, height: itemSize },
            { transform: [{ translateY: -(frame.width - itemSize) / 2 }] },
          ]}
        >
          { this._renderCellContent(itemIndex, index) }
        </View>
      </Animated.View>
    );
  }

  render() {
    const cellCount = this.cellCount;
    const cells = [];

    for (let i = 0; i < cellCount; i += 1) {
      cells.push(this._renderCell(i));
    }

    const animAngle = this.state.animRotate.interpolate({
      inputRange: [0.0, 720],
      outputRange: [
        '0deg', '720deg',
      ],
    });
    return (
      <View
        {...this.panHandler.panResponder.panHandlers}
        style={styles.container}
        onLayout={this._onLayout}
      >
        <Animated.View
          style={[
            styles.container,
            { transform: [{ rotate: animAngle }] },
          ]}
        >
          { cells }
        </Animated.View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    ...bs.layout.match_parent,
    // backgroundColor: '#ff000080'
  },
});
