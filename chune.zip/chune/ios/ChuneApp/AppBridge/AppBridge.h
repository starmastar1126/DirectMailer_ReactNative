//
//  AppBridge.h
//  chilllMobile
//
//  Created by Michael Lee on 3/17/17.
//  Copyright © 2017 Facebook. All rights reserved.
//

#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>

@interface AppBridge : RCTEventEmitter <RCTBridgeModule>

@end
