import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View,
    TouchableOpacity,
    Image,
    TextInput,
    Picker,
    Button,
    WebView,
} from 'react-native';
import Globals from '../Global';
import Dimensions from 'Dimensions';

export default class ProductScreen extends Component {
    static navigationOptions = (navigation) => {
        return {
            header: (
                <View
                  style={{
                    height: 45,
                    // marginTop: 20,
                    backgroundColor: Globals.BACKGROUDD_COLOR,
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}>
                  <TouchableOpacity onPress={() => alert('Right Menu Clicked')}>
                    <Text
                        style={{
                            color: 'white',
                            textAlign: 'center',
                            fontWeight: 'bold',
                            fontSize: 18,
                        }}>
                        {'<'}Back
                    </Text>
                  </TouchableOpacity>
                  <Text
                    style={{
                      color: 'white',
                      textAlign: 'center',
                      fontWeight: 'bold',
                      fontSize: 18,
                    }}>
                    Choose Your Product
                  </Text>
                  <View style={styles.person_view}>
                    <Text
                        style={{
                            color: 'white',
                            width: 48,
                            height: 48
                        }}>
                        
                    </Text>
                    {/* <Image source={person_icon} style={styles.person_icon}></Image> */}
                  </View>
                </View>
              ),
        };
    };  

    render() {
        return(
            <View style={styles.container}>

            </View>
        );
    }
}

const styles = StyleSheet.create({
        container:{
            flex:1,
            backgroundColor:Globals.BACKGROUDD_COLOR
        }
    }
);