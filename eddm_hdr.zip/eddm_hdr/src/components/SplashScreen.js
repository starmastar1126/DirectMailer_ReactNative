/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View,Image,TouchableOpacity,
} from 'react-native';
import Swiper from "react-native-web-swiper";
import Globals from './Global';
import Dimensions from 'Dimensions';
	
// import Slideshow from 'react-native-slideshow';

import splashImage1 from '../images/step1_splash_icon.png';
import splashImage2 from '../images/step2_splash_icon.png';
import splashImage3 from '../images/step3_splash_icon.png';

const instructions = Platform.select({
  ios: 'Press Cmd+R to reload,\n' + 'Cmd+D or shake for dev menu',
  android:
    'Double tap R on your keyboard to reload,\n' +
    'Shake or press menu button for dev menu',
});

// type Props = {};
export default class SplashScreen extends Component {

  static navigationOptions = {
    header: null
  };
  
  onStart() {
    this.props.navigation.navigate('GeographicScreen');
  }
  render() {
    return (
      <View style={styles.container}>
          <Swiper>
              <View style={[styles.slideContainer,styles.slide1]}>
                <View style={{justifyContent:'center',alignItems: 'center', width:'100%', height:'25%'}}>
                  <Image source={splashImage1} style={styles.imagecontainer}/>
                </View>
                <View style={{justifyContent:'center',alignItems: 'center', width:'100%', height:'25%'}}>
                  <Text style={styles.paragraph1}>Step 1{'\n'}Target the right{'\n'}prospects</Text>
                </View>
                <View style={{justifyContent:'center',alignItems: 'center', width:'100%', height:'25%'}}>
                  <Text style={styles.paragraph2}>Search for the best prospects{'\n'}using free, powerful geographic{'\n'}and demographic filters such as{'\n'}age, income, and drive-time from{'\n'}your business</Text>
                </View>
              </View>
              <View style={[styles.slideContainer,styles.slide2]}>
                <View style={{justifyContent:'center',alignItems: 'center', width:'100%', height:'25%'}}>
                  <Image source={splashImage2} style={styles.imagecontainer}/>
                </View>
                <View style={{justifyContent:'center',alignItems: 'center', width:'100%', height:'25%'}}>
                  <Text style={styles.paragraph1}>Step 2{'\n'}Create your offer</Text>
                </View>
                <View style={{justifyContent:'center',alignItems: 'center', width:'100%', height:'25%'}}>
                  <Text style={styles.paragraph2}>Choose the perfect design, print,{'\n'}and marketing options to build{'\n'}great-looking marketing{'\n'}campaigns for your needs</Text>
                </View>
              </View>
              <View style={[styles.slideContainer,styles.slide3]}>
                <View style={{justifyContent:'center',alignItems: 'center', width:'100%', height:'25%'}}>
                  <Image source={splashImage3} style={styles.imagecontainer}/>
                </View>
                <View style={{justifyContent:'center',alignItems: 'center', width:'100%', height:'25%'}}>
                  <Text style={styles.paragraph1}>Step 3{'\n'}Launch campaign</Text>
                </View>
                <View style={{justifyContent:'center',alignItems: 'center', width:'100%', height:'25%'}}>
                  <Text style={styles.paragraph2}>Our online mail delivery{'\n'}scheduleing system puts you in{'\n'}control while eliminating all{'\n'}paperwork and hassless from the{'\n'}process</Text>
                </View>
                <View style={{justifyContent:'center',alignItems: 'center', width:'100%', height:'25%'}}>
                  <TouchableOpacity style={styles.start_button} onPress={() => this.onStart()} activeOpacity={1}>
                        <Text style={styles.text_color}>
                            GET STARTED
                        </Text>
                  </TouchableOpacity>
                </View>
              </View>
          </Swiper>
      </View>
    );
  }
}

const DEVICE_WIDTH = Dimensions.get('window').width;

const styles = StyleSheet.create({
  // container: {
  //   flex: 1,
  //   justifyContent: 'center',
  //   alignItems: 'center',
  //   backgroundColor: '#F5FCFF',
  // },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
  MainContainer: {
      flex: 1,
      alignItems: 'center',
      paddingTop: (Platform.OS) === 'ios' ? 20 : 0,
      // backgroundColor: '#FFF8E1'
  
  },
container: {
    flex: 1,
    backgroundColor: '#3c3b47'
},
slideContainer: {
    flex: 1,
    alignItems: "center",
    width: '100%',
    height: '100%'
    // justifyContent: "center"
},
slide1: {
    backgroundColor: Globals.BACKGROUDD_COLOR
},
slide2: {
    backgroundColor: Globals.BACKGROUDD_COLOR
},
slide3: {
    backgroundColor: Globals.BACKGROUDD_COLOR
},
imagecontainer:{
  // marginTop: Dimensions.get('window').height * 0.12,
  width: 150,
  height: 150
          
},
paragraph1: {
  // marginTop: '20%',
  fontSize: 30,
  fontWeight: 'bold',
  textAlign: 'center',
  color: '#FFFFFF',
  // width:'100%',
  // height: '20%'
},
paragraph2: {
  // marginTop: '10%',
  fontSize: 18,
  fontWeight: 'bold',
  textAlign: 'center',
  color: '#FFFFFF',
},
start_button: {
  alignItems: 'center',
  justifyContent: 'center',
  width:'55%',
  height: 40,
  backgroundColor: '#009550',
  borderRadius: 5,
  color: '#ffffff',
  // marginTop: '15%'
},
text_color: {
  color: '#ffffff',
  // backgroundColor: GLOBALS.BASE_COLOR,
  fontWeight: 'bold',
  // marginTop: '13%'
},
});
