import { StyleSheet, Platform } from 'react-native';
import Dimensions from 'Dimensions';

export default {
    BACKGROUDD_COLOR: '#3c3b47',
    FORGROUND_COLOR: '#ffffff',
    DEVICE_WIDTH: Platform.isPad ? Dimensions.get('window').width/2 : Dimensions.get('window').width,
    DEVICE_HEIGHT: Dimensions.get('window').height,
}