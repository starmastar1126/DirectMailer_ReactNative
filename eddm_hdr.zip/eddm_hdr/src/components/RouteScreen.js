import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View,
    TouchableOpacity,
    Image,
    TextInput,
    Picker,
    Button,
    WebView,
} from 'react-native';
import Globals from './Global';
import Dimensions from 'Dimensions';
import CheckBox from 'react-native-check-box'

export default class RouteScreen extends Component {

    constructor () {
        super();
        this.state = {
          residentialChecked: false,
          businessChecked: false,
          boxChecked: false,
          residentialCount: 1063,
          businessCount: 35,
          boxCount: 1421,
          totalCount: 2519,
          mapname: ''
        };
    }
    static navigationOptions = (navigation) => {
        return {
            header: (
                <View
                  style={{
                    height: 45,
                    // marginTop: 20,
                    backgroundColor: Globals.BACKGROUDD_COLOR,
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}>
                  <TouchableOpacity onPress={() => alert('Right Menu Clicked')}>
                    <Text
                        style={{
                            color: 'white',
                            textAlign: 'center',
                            fontWeight: 'bold',
                            fontSize: 18,
                        }}>
                        {'<'}Back
                    </Text>
                  </TouchableOpacity>
                  <Text
                    style={{
                      color: 'white',
                      textAlign: 'center',
                      fontWeight: 'bold',
                      fontSize: 18,
                    }}>
                    Select Routes
                  </Text>
                  <View style={styles.person_view}>
                    <Text
                        style={{
                            color: 'white',
                            width: 48,
                            height: 48
                        }}>
                        
                    </Text>
                    {/* <Image source={person_icon} style={styles.person_icon}></Image> */}
                  </View>
                </View>
              ),
        };
    };  
    onSave() {
        this.props.navigation.navigate('ProductScreen');
    }
    render(){
        return(
            <View style={styles.container}>
                <View style={styles.savestyle}>
                    <View style={styles.infoview}>
                        <View style={{flexDirection: 'row',}}>
                            <CheckBox style={{backgroundColor: Globals.FORGROUND_COLOR}}
                                value={this.state.residentialChecked}
                                onClick={()=>{
                                    this.setState({
                                        residentialChecked:!this.state.residentialChecked
                                    })
                                }}
                                isChecked={this.state.residentialChecked}
                                // leftText={"CheckBox"}
                            />
                            <Text style={styles.paragraph}> Residential(Required)</Text>
                        </View>
                        <Text style={styles.paragraph}>{this.state.residentialCount}</Text>
                    </View>
                    <View style={styles.infoview}>
                        <View style={{flexDirection: 'row',}}>
                                <CheckBox style={{backgroundColor: Globals.FORGROUND_COLOR}}
                                    value={this.state.businessChecked}
                                    onClick={()=>{
                                        this.setState({
                                            businessChecked:!this.state.businessChecked
                                        })
                                    }}
                                    isChecked={this.state.businessChecked}
                                />
                                <Text style={styles.paragraph}> Business</Text>
                        </View>
                        <Text style={styles.paragraph}>{this.state.businessCount}</Text>
                    </View>
                    <View style={styles.infoview}>
                        <View style={{flexDirection: 'row',}}>
                                <CheckBox style={{backgroundColor: Globals.FORGROUND_COLOR}}
                                    value={this.state.boxChecked}
                                    onClick={()=>{
                                        this.setState({
                                            boxChecked:!this.state.boxChecked
                                        })
                                    }}
                                    isChecked={this.state.boxChecked}
                                />
                                <Text style={styles.paragraph}> PO Boxes</Text>
                        </View>
                        <Text style={styles.paragraph}>{this.state.boxCount}</Text>
                    </View>
                    <View style={styles.totalview}>
                        <Text style={styles.paragraph}>Total:</Text>
                        <Text style={styles.paragraph}>{this.state.totalCount}</Text>
                    </View>
                    <View style={styles.mapview}>
                        <TextInput
                            style={styles.mapnameinput}
                            placeholder="Input map name"
                            autoCorrect={false}
                            autoCapitalize={'none'}
                            returnKeyType='done'
                            placeholderTextColor="black"
                            underlineColorAndroid="transparent"
                            onChangeText={(mapname) => this.setState({mapname})}
                        />
                    </View>
                    <View style={styles.saveview}>
                        <TouchableOpacity style={styles.savebutton} onPress={() => this.onSave()} activeOpacity={1}>
                            <Text style={styles.text_color}>
                                SAVE {'&'} CONTINUE
                            </Text>
                        </TouchableOpacity>
                    </View>
                </View>
                <WebView style={styles.webview}
                    source = {{ uri:
                    'https://www.google.com/?gws_rd=cr,ssl&ei=SICcV9_EFqqk6ASA3ZaABA#q=tutorialspoint' }}
                />
                
            </View>
        );
    }
}
const styles= StyleSheet.create({
    container: {
        flex: 1,
        // justifyContent: 'center',
        // alignItems: 'center',
        backgroundColor: Globals.BACKGROUDD_COLOR,
      },
      savestyle: {
          width: '60%',
          height: '40%',
          right: 0,
          marginTop: 0,
          backgroundColor: Globals.BACKGROUDD_COLOR,
          position: 'absolute',
          zIndex: 99,
          borderRadius: 5,
          paddingLeft: 10,
          paddingRight: 10
      },
      webview: {
          marginTop: 0
      },
      infoview: {
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          width: '100%',
          height: '15%',
      },
      paragraph: {
        fontSize: 16,
        fontWeight: 'bold',
        textAlign: 'center',
        color: '#FFFFFF',
        backgroundColor: Globals.BACKGROUDD_COLOR
      },
      totalview: {
          flexDirection: 'row',
          justifyContent: 'space-around',
          alignItems: 'center',
          height: '15%'
      },
      mapview: {
          justifyContent: 'center',
          alignItems: 'center',
          width: '100%',
          height: '15%', 
        //   marginTop: 15
      },
      mapnameinput:{
        backgroundColor: '#ffffff',
        // height: 40,
        borderRadius: 5,
        color: Globals.BACKGROUDD_COLOR,
        width: '90%'
      },
      saveview:{
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 20,
        height: '15%',
        width: '100%'
      },
      savebutton: {
        alignItems: 'center',
        justifyContent: 'center',
        width:'80%',
        height: '90%',
        backgroundColor: '#009550',
        borderRadius: 5,
        color: '#ffffff',
      },
      text_color: {
        color: '#ffffff',
        fontWeight: 'bold',
      },
    }
);