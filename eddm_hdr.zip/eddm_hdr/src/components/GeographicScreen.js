/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View,
    TouchableOpacity,
    Image,
    TextInput,
    Picker,
    Button, KeyboardAvoidingView,
} from 'react-native';
import Globals from './Global';
import Dimensions from 'Dimensions';
import person_icon from '../images/person_icon.png';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';


// type Props = {};
export default class GeographicScreen extends Component {

  constructor (props) {
      super(props);
      this.state = {
        address : "",
        zipcode: "",
        measureType: '',
        filter1: '',
        filter2: '',
        filter3: ''
      };
  }  
  static navigationOptions = (navigation) => {
        return {
            
            header: (
                <View
                  style={{
                    height: 45,
                    // marginTop: 20,
                    backgroundColor: Globals.BACKGROUDD_COLOR,
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}>
                  <TouchableOpacity onPress={() => alert('Right Menu Clicked')}>
                    <Text
                        style={{
                            color: 'white',
                            width: 48,
                            height: 48
                        }}>
                        
                    </Text>
                  </TouchableOpacity>
                  <Text
                    style={{
                      color: 'white',
                      textAlign: 'center',
                      fontWeight: 'bold',
                      fontSize: 18,
                    }}>
                    Get Started
                  </Text>
                  <View style={styles.person_view}>
                    <Image source={person_icon} style={styles.person_icon}></Image>
                  </View>
                </View>
              ),
            
        };
  };
  updateMeasure =(type) => {
    this.setState({measureType: type});
  }
  updateFilter1 =(filter) => {
    this.setState({filter1: filter});
  }
  updateFilter2 =(filter) => {
    this.setState({filter2: filter});
  }
  updateFilter3 =(filter) => {
    this.setState({filter3: filter});
  }
  onProspect() {
    this.props.navigation.navigate('RouteScreen');
  }
  render() {
    return (
      <View style={styles.container} >
        <View style={styles.graphview}>
            <Text style={styles.common_textstyle}>Geographics Targeting</Text>
        </View>
        <View style={styles.graphview}>
            <Text style={styles.common_textstyle}>Enter a centrally located address to Mail around</Text>
        </View>
        <View style={styles.addressview}>
            <TextInput
                style={styles.addressinput}
                placeholder="Street address"
                autoCorrect={false}
                autoCapitalize={'none'}
                returnKeyType='done'
                placeholderTextColor="black"
                underlineColorAndroid="transparent"
                onChangeText={(address) => this.setState({address})}
            />
        </View>
        <View style={styles.areaview}>
            <TextInput
                style={styles.zipcodeinput}
                placeholder="Zip Code"
                autoCorrect={false}
                autoCapitalize={'none'}
                returnKeyType='done'
                placeholderTextColor="black"
                underlineColorAndroid="transparent"
                onChangeText={(zipcode) => this.setState({zipcode})}
            />
            <Picker style={styles.pickerstyle} selectedValue = {this.state.measureType} onValueChange={this.updateMeasure}>
                <Picker.Item label = "Distance" value = "Measure Distance" />
                <Picker.Item label = "Drivetime" value = "Drivetime" />
                <Picker.Item label = "Radius" value = "Radius" />
            </Picker>
        </View>
        <View style={styles.graphview}>
            <Text style={styles.common_textstyle}>DemoGraphic Targeting</Text>
        </View>
        <View style={{flexDirection: 'row', justifyContent: 'flex-start', alignItems:'center', width:'100%', height:'10%'}}>
            <Text style={styles.common_textstyle}>User filters such as age, income, home ownership, and more to target the best prospects</Text>
        </View>
        <View style={styles.filterview}>
            <Picker style={styles.filterstyle} selectedValue = {this.state.filter1} onValueChange={this.updateFilter1}>
                <Picker.Item label = "Add Filter" value = "Add Filter" />
                <Picker.Item label = "Household Income" value = "Household Income" />
                <Picker.Item label = "Age" value = "Age" />
                <Picker.Item label = "Home Ownership" value = "Home Ownership" />
                <Picker.Item label = "Gender" value = "Gender" />
                <Picker.Item label = "presence of Children" value = "Presence of Children" />
            </Picker>
            <Picker style={styles.filterstyle} selectedValue = {this.state.filter2} onValueChange={this.updateFilter2}>
                <Picker.Item label = "Add Filter" value = "Add Filter" />
                <Picker.Item label = "Household Income" value = "Household Income" />
                <Picker.Item label = "Age" value = "Age" />
                <Picker.Item label = "Home Ownership" value = "Home Ownership" />
                <Picker.Item label = "Gender" value = "Gender" />
                <Picker.Item label = "presence of Children" value = "Presence of Children" />
            </Picker>
            <Picker style={styles.filterstyle} selectedValue = {this.state.filter3} onValueChange={this.updateFilter3}>
                <Picker.Item label = "Add Filter" value = "Add Filter" />
                <Picker.Item label = "Household Income" value = "Household Income" />
                <Picker.Item label = "Age" value = "Age" />
                <Picker.Item label = "Home Ownership" value = "Home Ownership" />
                <Picker.Item label = "Gender" value = "Gender" />
                <Picker.Item label = "presence of Children" value = "Presence of Children" />
            </Picker>
        </View>
        <View style={styles.prospectview}>
          <TouchableOpacity style={styles.prospect_button} onPress={() => this.onProspect()} activeOpacity={1}>
                <Text style={styles.text_color}>
                    SHOW ME MY PROSPECTS
                </Text>
          </TouchableOpacity>
        </View>
      </View>
      
    );
  }
}

const styles = StyleSheet.create({
  
  container: {
    flex: 1,
    paddingLeft: 10,
    paddingRight: 10, 
    backgroundColor: Globals.BACKGROUDD_COLOR,
  },
  person_view:{
  },
  person_icon: {
      width: 48,
      height: 48
  },
  graphview:{
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'flex-end',
    backgroundColor: Globals.BACKGROUDD_COLOR,
    width: '100%',
    height: '10%'
  },
  common_textstyle: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'left',
    color: Globals.FORGROUND_COLOR,
  },
  addressview: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    height: '9%',
  },
  addressinput: {
    backgroundColor: '#ffffff',
    width: '100%',
    height: '80%',
    borderRadius: 5,
    color: Globals.BACKGROUDD_COLOR,
  },
  areaview: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: '9%',
  },
  zipcodeinput:{
    backgroundColor: '#ffffff',
    width: '23%',
    height: '80%',
    borderRadius: 5,
    color: Globals.BACKGROUDD_COLOR,
  },
  pickerstyle: {
    backgroundColor: '#ffffff',
    width: '73%',
    height: '80%',
    borderRadius: 5,
    color: Globals.BACKGROUDD_COLOR,
    // marginLeft: 10,
  },
  // targetview: {
  //   flexDirection: 'column',
  //   justifyContent: 'center',
  //   alignItems: 'center',
  //   marginTop: 10,
  //   // marginLeft: 10,
  //   // marginRight: 10,
  //   // width: '95%',
  //   height: '20%'
  // },
  filterview: {
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    height: '20%',
  },
  filterstyle: {
    backgroundColor: '#ffffff',
    height: '30%',
    borderRadius: 5,
    color: Globals.BACKGROUDD_COLOR,
    width: '100%',
    marginTop: 10
  },
  prospectview:{
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'flex-end',
    height: '17%'
  },
  prospect_button: {
    alignItems: 'center',
    justifyContent: 'center',
    width:'80%',
    height: 40,
    backgroundColor: '#009550',
    borderRadius: 5,
    color: '#ffffff',
    
  },
  text_color: {
    color: '#ffffff',
    fontWeight: 'bold',
  },
});
