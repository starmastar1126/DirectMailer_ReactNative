
import SplashScreen from './SplashScreen';
import GeographicScreen from './GeographicScreen';
import RouteScreen from './RouteScreen';
import ProductScreen from './product/ProductScreen';

import { createAppContainer, createStackNavigator } from 'react-navigation';
import { Dimensions } from 'react-native';

const deviceW = Dimensions.get('window').width;

const basePx = 375;

const MoonMinerNavigator = createStackNavigator({
    Splashcreen: {screen: SplashScreen},
    GeographicScreen: {screen: GeographicScreen,},
    RouteScreen: {screen: RouteScreen},
    ProductScreen: {screen: ProductScreen}
},
{
    initialRouteName: 'Splashcreen'
});
const AppContainer = createAppContainer(MoonMinerNavigator);
export default AppContainer;