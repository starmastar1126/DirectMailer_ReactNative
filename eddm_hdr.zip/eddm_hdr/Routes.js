import React from 'react'
import { Router, Scene } from 'react-native-router-flux'
import SplashScreen from './src/components/SplashScreen'

const Routes = () => (
    <Router>
       <Scene key = "root">
          <Scene key = "SplashScreen" component = {SplashScreen} title = "SplashScreen" initial = {true} />
          {/* <Scene key = "about" component = {About} title = "About" /> */}
       </Scene>
    </Router>
 )
 export default Routes